"use client";
import clsx from "clsx";
import { Loader2 } from "lucide-react";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "gold"; loading?: boolean; size?: "sm" | "md" | "lg" };

export function Button({ variant = "primary", loading, size = "md", className, children, disabled, ...rest }: Props) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={clsx(
        "inline-flex items-center justify-center gap-2 rounded-2xl font-semibold transition active:scale-[.97] disabled:cursor-not-allowed disabled:opacity-50",
        size === "sm" && "px-3.5 py-2 text-xs", size === "md" && "px-5 py-3 text-sm", size === "lg" && "px-6 py-4 text-base",
        variant === "primary" && "btn-primary text-white",
        variant === "gold" && "bg-gradient-to-r from-amber-300 to-orange-400 text-night-950 shadow-[0_8px_28px_-8px_rgba(251,191,36,.7)]",
        variant === "ghost" && "border border-white/10 bg-white/5 text-white hover:bg-white/10",
        variant === "danger" && "bg-rose-500/90 text-white hover:bg-rose-500",
        className,
      )}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}
