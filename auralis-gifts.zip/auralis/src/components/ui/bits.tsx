"use client";
import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import { animate } from "framer-motion";
import { AlertTriangle } from "lucide-react";
import { Button } from "./Button";
import { RARITY, type RarityKey } from "@/lib/rarity";
import { fmt } from "@/lib/client";

export const Glass = ({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) => <div {...p} className={clsx("glass rounded-3xl", className)} />;

export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx("relative overflow-hidden rounded-2xl bg-white/[.06]", className)}><div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/10 to-transparent" /></div>;
}

export function EmptyState({ emoji, title, text, action }: { emoji: string; title: string; text: string; action?: React.ReactNode }) {
  return (
    <div className="glass flex flex-col items-center rounded-3xl px-6 py-10 text-center">
      <div className="mb-3 text-4xl">{emoji}</div>
      <h3 className="font-display text-base font-medium">{title}</h3>
      <p className="mt-1.5 max-w-[16rem] text-sm text-white/55">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="glass flex flex-col items-center rounded-3xl px-6 py-9 text-center">
      <AlertTriangle className="mb-3 h-8 w-8 text-amber-400" />
      <p className="text-sm text-white/70">{message}</p>
      {onRetry && <Button variant="ghost" size="sm" className="mt-4" onClick={onRetry}>Try again</Button>}
    </div>
  );
}

export function RarityBadge({ rarity, className }: { rarity: RarityKey; className?: string }) {
  const r = RARITY[rarity];
  return <span className={clsx("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold", className)} style={{ color: r.color, background: `${r.color}22`, border: `1px solid ${r.color}44` }}>{r.label}</span>;
}

export function AnimatedNumber({ value, className }: { value: number; className?: string }) {
  const [shown, setShown] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    const c = animate(prev.current, value, { duration: 0.7, ease: "easeOut", onUpdate: (v) => setShown(Math.round(v)) });
    prev.current = value;
    return () => c.stop();
  }, [value]);
  return <span className={className}>{fmt(shown)}</span>;
}

export function Avatar({ name, src, size = 44 }: { name: string; src?: string | null; size?: number }) {
  const [bad, setBad] = useState(false);
  if (src && !bad) return <img src={src} alt="" width={size} height={size} onError={() => setBad(true)} className="rounded-full object-cover ring-2 ring-white/15" style={{ width: size, height: size }} />;
  return <div className="grid place-items-center rounded-full bg-gradient-to-br from-aura-violet to-aura-blue font-display font-bold ring-2 ring-white/15" style={{ width: size, height: size, fontSize: size * 0.4 }}>{name.slice(0, 1).toUpperCase()}</div>;
}

export function PointsPill({ value }: { value: number }) {
  return <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-sm font-bold"><span className="text-amber-300">◆</span><AnimatedNumber value={value} /></span>;
}
