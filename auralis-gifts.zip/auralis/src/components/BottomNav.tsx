"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { Gift, Home, Rocket, User, Users } from "lucide-react";
import clsx from "clsx";

const TABS = [
  { href: "/", label: "Home", Icon: Home },
  { href: "/inventory", label: "Gifts", Icon: Gift },
  { href: "/rocket", label: "Rocket", Icon: Rocket },
  { href: "/referrals", label: "Friends", Icon: Users },
  { href: "/profile", label: "Profile", Icon: User },
];

export function BottomNav() {
  const path = usePathname();
  return (
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      <div className="glass flex items-center justify-between rounded-[1.75rem] bg-night-900/80 p-1.5">
        {TABS.map(({ href, label, Icon }) => {
          const active = href === "/" ? path === "/" : path.startsWith(href);
          return (
            <Link key={href} href={href} aria-current={active ? "page" : undefined} className="relative flex flex-1 flex-col items-center gap-0.5 rounded-[1.4rem] py-2.5">
              {active && <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-[1.4rem] btn-primary" transition={{ type: "spring", damping: 28, stiffness: 380 }} />}
              <Icon className={clsx("relative h-5 w-5 transition", active ? "text-white" : "text-white/45")} />
              <span className={clsx("relative text-[11px] font-semibold transition", active ? "text-white" : "text-white/45")}>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
