"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, Send } from "lucide-react";
import { api, errMsg, setToken, ApiClientError } from "@/lib/client";
import type { PublicUser } from "@/lib/types";
import { Button } from "./ui/Button";

declare global {
  interface Window { Telegram?: { WebApp: any } }
}

type Toast = { id: number; msg: string; kind: "ok" | "err" };
type Ctx = {
  user: PublicUser;
  setBalance: (n: number) => void;
  refresh: () => Promise<void>;
  toast: (msg: string, kind?: "ok" | "err") => void;
  haptic: (k: "light" | "success" | "error") => void;
  tg: any | null;
};
const AppCtx = createContext<Ctx | null>(null);
export const useApp = () => {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp outside provider");
  return c;
};

type Phase = { s: "loading" } | { s: "outside" } | { s: "error"; msg: string; banned?: boolean } | { s: "ready" };

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [phase, setPhase] = useState<Phase>({ s: "loading" });
  const [user, setUser] = useState<PublicUser | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [tg, setTg] = useState<any | null>(null);

  const boot = useCallback(async () => {
    setPhase({ s: "loading" });
    // the Telegram SDK script may still be loading
    for (let i = 0; i < 40 && !window.Telegram?.WebApp; i++) await new Promise((r) => setTimeout(r, 100));
    const w = window.Telegram?.WebApp ?? null;
    try {
      w?.ready(); w?.expand(); w?.setHeaderColor?.("#07060f"); w?.setBackgroundColor?.("#07060f"); w?.disableVerticalSwipes?.();
    } catch {}
    setTg(w);
    try {
      let res: { token: string; user: PublicUser };
      if (w?.initData) res = await api("/auth/telegram", { body: { initData: w.initData } });
      else if (process.env.NEXT_PUBLIC_ALLOW_DEV_LOGIN === "true") res = await api("/auth/dev", { method: "POST", body: {} });
      else return setPhase({ s: "outside" });
      setToken(res.token);
      setUser(res.user);
      setPhase({ s: "ready" });
    } catch (e) {
      setPhase({ s: "error", msg: errMsg(e), banned: e instanceof ApiClientError && e.code === "banned" });
    }
  }, []);
  useEffect(() => { boot(); }, [boot]);

  const toast = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);
  const haptic = useCallback((k: "light" | "success" | "error") => {
    try {
      if (k === "light") tg?.HapticFeedback?.impactOccurred("light");
      else tg?.HapticFeedback?.notificationOccurred(k);
    } catch {}
  }, [tg]);
  const setBalance = useCallback((balance: number) => setUser((u) => (u ? { ...u, balance } : u)), []);
  const refresh = useCallback(async () => {
    try { setUser((await api<{ user: PublicUser }>("/me")).user); } catch {}
  }, []);

  const value = useMemo(() => (user ? { user, setBalance, refresh, toast, haptic, tg } : null), [user, setBalance, refresh, toast, haptic, tg]);

  if (phase.s === "loading") return <Splash />;
  if (phase.s === "outside") return <Notice icon={<Send className="h-7 w-7" />} title="Open this from Telegram" text="This app signs you in through Telegram. Open it from the bot's Open button." />;
  if (phase.s === "error") return <Notice icon={<AlertTriangle className="h-7 w-7" />} title={phase.banned ? "Account suspended" : "Couldn't sign you in"} text={phase.msg} action={phase.banned ? undefined : <Button onClick={boot}>Try again</Button>} />;

  return (
    <AppCtx.Provider value={value!}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-[max(0.75rem,env(safe-area-inset-top))] z-[70] flex flex-col items-center gap-2 px-4">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div key={t.id} initial={{ y: -20, opacity: 0, scale: 0.96 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ opacity: 0, y: -10 }}
              className="glass pointer-events-auto flex max-w-sm items-center gap-2 rounded-2xl px-4 py-3 text-sm font-medium" role="status">
              {t.kind === "ok" ? <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" /> : <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />}
              {t.msg}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </AppCtx.Provider>
  );
}

function Splash() {
  return (
    <div className="sky grid min-h-dvh place-items-center">
      <motion.div animate={{ scale: [1, 1.12, 1], opacity: [0.7, 1, 0.7] }} transition={{ repeat: Infinity, duration: 1.8 }}
        className="h-16 w-16 rounded-3xl btn-primary" aria-label="Loading" />
    </div>
  );
}

function Notice({ icon, title, text, action }: { icon: React.ReactNode; title: string; text: string; action?: React.ReactNode }) {
  return (
    <div className="sky grid min-h-dvh place-items-center px-6">
      <div className="glass w-full max-w-sm rounded-3xl p-7 text-center">
        <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-white/10">{icon}</div>
        <h1 className="font-display text-lg font-medium">{title}</h1>
        <p className="mt-2 text-sm text-white/60">{text}</p>
        {action && <div className="mt-5 flex justify-center">{action}</div>}
      </div>
    </div>
  );
}
