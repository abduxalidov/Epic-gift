"use client";
import { motion } from "framer-motion";

/** Original illustrated gift box. `shaking` while a box is being opened, `open` lifts the lid. */
export function GiftBoxArt({ size = 160, shaking = false, open = false }: { size?: number; shaking?: boolean; open?: boolean }) {
  return (
    <motion.svg
      viewBox="0 0 160 160" width={size} height={size} aria-hidden
      animate={shaking ? { rotate: [0, -7, 7, -9, 9, -5, 5, 0], y: [0, -3, 0, -6, 0] } : { y: [0, -6, 0] }}
      transition={shaking ? { duration: 0.45, repeat: Infinity } : { duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
    >
      <defs>
        <linearGradient id="gb-body" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#8b5cf6" /><stop offset="1" stopColor="#3b3ccf" /></linearGradient>
        <linearGradient id="gb-lid" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#a78bfa" /><stop offset="1" stopColor="#5b4ae0" /></linearGradient>
        <linearGradient id="gb-gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fde68a" /><stop offset="1" stopColor="#f59e0b" /></linearGradient>
        <radialGradient id="gb-glow" cx=".5" cy=".5" r=".5"><stop offset="0" stopColor="#fde68a" stopOpacity=".9" /><stop offset="1" stopColor="#fde68a" stopOpacity="0" /></radialGradient>
      </defs>
      {open && <circle cx="80" cy="70" r="62" fill="url(#gb-glow)" />}
      <ellipse cx="80" cy="150" rx="46" ry="6" fill="#000" opacity=".35" />
      <rect x="28" y="74" width="104" height="72" rx="14" fill="url(#gb-body)" />
      <rect x="72" y="74" width="16" height="72" fill="url(#gb-gold)" />
      <rect x="28" y="74" width="104" height="10" fill="#000" opacity=".12" />
      <motion.g animate={open ? { y: -30, rotate: -14 } : { y: 0, rotate: 0 }} style={{ transformOrigin: "26px 74px" }} transition={{ type: "spring", damping: 12 }}>
        <rect x="20" y="52" width="120" height="28" rx="11" fill="url(#gb-lid)" />
        <rect x="72" y="52" width="16" height="28" fill="url(#gb-gold)" />
        <path d="M80 52C66 28 38 32 46 48c5 9 24 5 34 4Z" fill="url(#gb-gold)" />
        <path d="M80 52C94 28 122 32 114 48c-5 9-24 5-34 4Z" fill="url(#gb-gold)" opacity=".92" />
        <circle cx="80" cy="52" r="7" fill="#f59e0b" />
      </motion.g>
      <path d="M130 30l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="#fff" opacity=".85" />
      <path d="M26 24l1.6 3.8 3.8 1.6-3.8 1.6L26 35l-1.6-4-3.8-1.6 3.8-1.6z" fill="#c4b5fd" opacity=".9" />
    </motion.svg>
  );
}
