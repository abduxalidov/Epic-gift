import clsx from "clsx";
import { RARITY } from "@/lib/rarity";
import type { GiftDto } from "@/lib/types";

/** Original gift tile: rarity-tinted glow plate around the gift's emoji or uploaded image. */
export function GiftArt({ gift, size = 88, lively = false }: { gift: Pick<GiftDto, "rarity" | "emoji" | "imageUrl" | "name">; size?: number; lively?: boolean }) {
  const r = RARITY[gift.rarity];
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div className={clsx("absolute inset-1 rounded-[30%] blur-xl", lively && "animate-glow")} style={{ background: r.glow }} />
      <div className="relative h-full w-full overflow-hidden rounded-[30%] p-[2px]" style={{ background: r.gradient }}>
        <div className="grid h-full w-full place-items-center rounded-[28%]" style={{ background: `radial-gradient(circle at 30% 18%, ${r.color}40, #0c0a1a 72%)` }}>
          {gift.imageUrl ? (
            <img src={gift.imageUrl} alt={gift.name} className="h-[78%] w-[78%] object-contain" loading="lazy" />
          ) : (
            <span role="img" aria-label={gift.name} className={clsx(lively && "animate-float")} style={{ fontSize: size * 0.48, lineHeight: 1 }}>{gift.emoji}</span>
          )}
        </div>
        {gift.rarity === "LEGENDARY" && <div className="pointer-events-none absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/25 to-transparent" />}
      </div>
    </div>
  );
}
