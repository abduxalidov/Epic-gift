"use client";
import { useState } from "react";
import { Repeat } from "lucide-react";
import { Sheet } from "../ui/Sheet";
import { Button } from "../ui/Button";
import { RarityBadge } from "../ui/bits";
import { GiftArt } from "./GiftArt";
import { useApp } from "../AppProvider";
import { api, errMsg, fmt, fmtDate } from "@/lib/client";
import type { GiftDto } from "@/lib/types";

type Props = {
  gift: GiftDto | null;
  onClose: () => void;
  /** inventory item ids of this gift (for exchange). Empty/undefined = catalog view */
  itemIds?: string[];
  acquiredAt?: string;
  canExchange?: boolean;
  onExchanged?: () => void;
};

export function GiftSheet({ gift, onClose, itemIds, acquiredAt, canExchange = true, onExchanged }: Props) {
  const { setBalance, toast, haptic } = useApp();
  const [busy, setBusy] = useState(false);

  async function exchange() {
    if (!gift || !itemIds?.length) return;
    setBusy(true);
    try {
      const r = await api<{ points: number; balance: number }>("/inventory/exchange", { body: { inventoryId: itemIds[0] } });
      setBalance(r.balance);
      haptic("success");
      toast(`Exchanged for ${fmt(r.points)} demo points`);
      onExchanged?.();
      onClose();
    } catch (e) {
      haptic("error");
      toast(errMsg(e), "err");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Sheet open={!!gift} onClose={onClose} title={gift?.name}>
      {gift && (
        <div className="flex flex-col items-center text-center">
          <GiftArt gift={gift} size={148} lively />
          <h2 className="mt-5 font-display text-xl font-medium">{gift.name}</h2>
          <div className="mt-2"><RarityBadge rarity={gift.rarity} /></div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/65">{gift.description}</p>
          <dl className="mt-5 grid w-full grid-cols-2 gap-3 text-left">
            <div className="rounded-2xl bg-white/5 p-3"><dt className="text-xs text-white/45">Exchange value</dt><dd className="mt-0.5 font-bold"><span className="text-amber-300">◆</span> {fmt(gift.exchangeValue)}</dd></div>
            <div className="rounded-2xl bg-white/5 p-3"><dt className="text-xs text-white/45">{acquiredAt ? "Collected" : "In your inventory"}</dt><dd className="mt-0.5 font-bold">{acquiredAt ? fmtDate(acquiredAt) : itemIds?.length ?? 0}</dd></div>
          </dl>
          {itemIds && itemIds.length > 0 && (
            <Button className="mt-6 w-full" loading={busy} disabled={!canExchange} onClick={exchange}>
              <Repeat className="h-4 w-4" /> {canExchange ? `Exchange one for ${fmt(gift.exchangeValue)} points` : "Exchange is switched off"}
            </Button>
          )}
          <p className="mt-3 text-xs text-white/35">Demo points can't be withdrawn or transferred.</p>
        </div>
      )}
    </Sheet>
  );
}
