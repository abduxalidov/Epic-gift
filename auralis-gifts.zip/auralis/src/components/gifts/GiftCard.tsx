import { RARITY } from "@/lib/rarity";
import type { GiftDto } from "@/lib/types";
import { GiftArt } from "./GiftArt";
import { RarityBadge } from "../ui/bits";

export function GiftCard({ gift, count, dim, onClick }: { gift: GiftDto; count?: number; dim?: boolean; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="glass relative flex flex-col items-center gap-2 rounded-3xl p-3 pt-4 text-center transition active:scale-[.97]" style={{ opacity: dim ? 0.45 : 1, boxShadow: `0 14px 40px -24px ${RARITY[gift.rarity].glow}` }}>
      {count && count > 1 && <span className="absolute right-2.5 top-2.5 rounded-full bg-white/15 px-2 py-0.5 text-[11px] font-bold">×{count}</span>}
      <GiftArt gift={gift} size={76} />
      <div className="w-full">
        <div className="truncate text-[13px] font-semibold">{gift.name}</div>
        <div className="mt-1"><RarityBadge rarity={gift.rarity} /></div>
      </div>
    </button>
  );
}
