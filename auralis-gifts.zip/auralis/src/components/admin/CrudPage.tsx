"use client";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { adm, useAdm } from "@/lib/admin-client";
import { Btn, Card, Empty, Label, Modal, PageState, Toggle, canWrite, useAdminUi } from "./ui";

export type Field = {
  key: string; label: string; type: "text" | "number" | "bool" | "select" | "textarea" | "datetime" | "image";
  options?: [string, string][]; nullable?: boolean; hint?: string; max?: number; min?: number;
};
type Props = {
  title: string; itemName: string; endpoint: string; fields: Field[]; defaults: Record<string, any>;
  columns: { label: string; render: (row: any) => React.ReactNode }[];
  /** extra action in the header, e.g. "Generate code" helpers */
  prepare?: (v: Record<string, any>) => Record<string, any>;
};

const toLocalInput = (d: string | null) => (d ? new Date(new Date(d).getTime() - new Date(d).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : "");

export function CrudPage({ title, itemName, endpoint, fields, defaults, columns, prepare }: Props) {
  const { role, notify } = useAdminUi();
  const write = canWrite(role);
  const { data, error, loading, reload } = useAdm<{ items: any[] }>(endpoint);
  const [editing, setEditing] = useState<{ id: string | null; v: Record<string, any> } | null>(null);
  const [busy, setBusy] = useState(false);

  const open = (row?: any) => setEditing(row
    ? { id: row.id, v: Object.fromEntries(fields.map((f) => [f.key, f.type === "datetime" ? toLocalInput(row[f.key]) : row[f.key] ?? (f.nullable ? "" : defaults[f.key])])) }
    : { id: null, v: { ...defaults } });

  async function save() {
    if (!editing) return;
    setBusy(true);
    try {
      const body: Record<string, any> = {};
      for (const f of fields) {
        const raw = (prepare ? prepare(editing.v) : editing.v)[f.key];
        if (f.type === "number") body[f.key] = raw === "" || raw === null ? (f.nullable ? null : 0) : Number(raw);
        else if (f.type === "datetime") body[f.key] = raw ? new Date(raw).toISOString() : null;
        else if (f.type === "image") body[f.key] = raw || null;
        else body[f.key] = raw;
      }
      await adm(editing.id ? `${endpoint}/${editing.id}` : endpoint, { method: editing.id ? "PATCH" : "POST", body });
      notify(editing.id ? "Changes saved" : `${itemName} created`);
      setEditing(null); reload();
    } catch (e) { notify(e instanceof Error ? e.message : "Couldn't save", "err"); } finally { setBusy(false); }
  }

  async function remove(row: any) {
    if (!confirm(`Delete this ${itemName.toLowerCase()}?`)) return;
    try {
      const r = await adm<{ retired?: boolean }>(`${endpoint}/${row.id}`, { method: "DELETE" });
      notify(r.retired ? "Players own this gift, so it was switched off instead of deleted." : `${itemName} deleted`);
      reload();
    } catch (e) { notify(e instanceof Error ? e.message : "Couldn't delete", "err"); }
  }

  async function upload(key: string, file: File) {
    const form = new FormData(); form.append("file", file);
    try { const r = await adm<{ url: string }>("/upload", { form }); setEditing((s) => s && { ...s, v: { ...s.v, [key]: r.url } }); }
    catch (e) { notify(e instanceof Error ? e.message : "Upload failed", "err"); }
  }

  const set = (k: string, val: any) => setEditing((s) => s && { ...s, v: { ...s.v, [k]: val } });

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <h1 className="font-display text-2xl font-medium">{title}</h1>
        {write && <Btn onClick={() => open()}><Plus className="h-4 w-4" /> New {itemName.toLowerCase()}</Btn>}
      </div>
      <PageState loading={loading} error={error} onRetry={reload}>
        <Card className="overflow-x-auto p-0">
          {data?.items.length ? (
            <table className="w-full text-left text-sm">
              <thead className="border-b border-white/10 text-xs text-white/45"><tr>{columns.map((c) => <th key={c.label} className="px-4 py-3 font-medium">{c.label}</th>)}{write && <th className="px-4 py-3" />}</tr></thead>
              <tbody className="divide-y divide-white/5">
                {data.items.map((row) => (
                  <tr key={row.id} className="hover:bg-white/[.03]">
                    {columns.map((c) => <td key={c.label} className="px-4 py-3">{c.render(row)}</td>)}
                    {write && <td className="whitespace-nowrap px-4 py-3 text-right"><button aria-label="Edit" onClick={() => open(row)} className="rounded-lg p-2 hover:bg-white/10"><Pencil className="h-4 w-4" /></button><button aria-label="Delete" onClick={() => remove(row)} className="rounded-lg p-2 text-rose-400 hover:bg-white/10"><Trash2 className="h-4 w-4" /></button></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <Empty text={`No ${itemName.toLowerCase()}s yet. Create the first one.`} />}
        </Card>
      </PageState>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? `Edit ${itemName.toLowerCase()}` : `New ${itemName.toLowerCase()}`}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }} className="grid gap-4 sm:grid-cols-2">
            {fields.map((f) => (
              <div key={f.key} className={f.type === "textarea" || f.type === "image" ? "sm:col-span-2" : ""}>
                {f.type === "bool" ? (
                  <div className="flex items-center justify-between rounded-xl bg-white/5 px-3.5 py-2.5"><span className="text-sm">{f.label}</span><Toggle checked={!!editing.v[f.key]} onChange={(v) => set(f.key, v)} label={f.label} /></div>
                ) : (
                  <>
                    <Label htmlFor={`f-${f.key}`} hint={f.hint}>{f.label}</Label>
                    {f.type === "select" ? (
                      <select id={`f-${f.key}`} className="field" value={editing.v[f.key] ?? ""} onChange={(e) => set(f.key, e.target.value)}>{f.options!.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
                    ) : f.type === "textarea" ? (
                      <textarea id={`f-${f.key}`} className="field" rows={3} maxLength={f.max} value={editing.v[f.key] ?? ""} onChange={(e) => set(f.key, e.target.value)} />
                    ) : f.type === "image" ? (
                      <div className="flex items-center gap-3">
                        {editing.v[f.key] ? <img src={editing.v[f.key]} alt="" className="h-14 w-14 rounded-xl object-contain bg-white/5" /> : <div className="grid h-14 w-14 place-items-center rounded-xl bg-white/5 text-xs text-white/35">none</div>}
                        <input id={`f-${f.key}`} type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={(e) => e.target.files?.[0] && upload(f.key, e.target.files[0])} className="text-xs text-white/60 file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-2 file:text-white" />
                        {editing.v[f.key] && <Btn type="button" variant="ghost" onClick={() => set(f.key, "")}>Remove</Btn>}
                      </div>
                    ) : (
                      <input id={`f-${f.key}`} className="field" type={f.type === "number" ? "number" : f.type === "datetime" ? "datetime-local" : "text"} min={f.min} maxLength={f.max} value={editing.v[f.key] ?? ""} onChange={(e) => set(f.key, e.target.value)} />
                    )}
                  </>
                )}
              </div>
            ))}
            <div className="flex justify-end gap-2 pt-2 sm:col-span-2"><Btn type="button" variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn><Btn type="submit" loading={busy}>Save</Btn></div>
          </form>
        )}
      </Modal>
    </div>
  );
}
