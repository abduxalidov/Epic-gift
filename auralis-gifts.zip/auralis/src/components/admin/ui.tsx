"use client";
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import clsx from "clsx";
import { Loader2, X } from "lucide-react";

type Role = "SUPER_ADMIN" | "MANAGER" | "SUPPORT";
export const RoleCtx = createContext<{ role: Role; notify: (m: string, kind?: "ok" | "err") => void }>({ role: "SUPPORT", notify: () => {} });
export const useAdminUi = () => useContext(RoleCtx);
export const canWrite = (r: Role) => r !== "SUPPORT";

export function ToastHost({ children, role }: { children: React.ReactNode; role: Role }) {
  const [t, setT] = useState<{ id: number; m: string; kind: string }[]>([]);
  const notify = useCallback((m: string, kind: "ok" | "err" = "ok") => {
    const id = Date.now();
    setT((x) => [...x, { id, m, kind }]);
    setTimeout(() => setT((x) => x.filter((i) => i.id !== id)), 3500);
  }, []);
  return (
    <RoleCtx.Provider value={{ role, notify }}>
      {children}
      <div className="fixed bottom-4 right-4 z-[80] space-y-2" role="status">
        {t.map((i) => <div key={i.id} className={clsx("rounded-xl px-4 py-2.5 text-sm font-medium shadow-xl", i.kind === "ok" ? "bg-emerald-500 text-white" : "bg-rose-500 text-white")}>{i.m}</div>)}
      </div>
    </RoleCtx.Provider>
  );
}

export const Card = ({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) => <div {...p} className={clsx("rounded-2xl border border-white/10 bg-white/[.04] p-5", className)} />;

export function Btn({ variant = "primary", loading, className, children, disabled, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger"; loading?: boolean }) {
  return (
    <button {...p} disabled={disabled || loading} className={clsx("inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition disabled:opacity-50",
      variant === "primary" && "bg-violet-600 text-white hover:bg-violet-500", variant === "ghost" && "border border-white/10 bg-white/5 hover:bg-white/10", variant === "danger" && "bg-rose-600 text-white hover:bg-rose-500", className)}>
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}{children}
    </button>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={clsx("max-h-[90dvh] w-full overflow-y-auto rounded-2xl border border-white/10 bg-night-900 p-6", wide ? "max-w-3xl" : "max-w-lg")}>
        <div className="mb-5 flex items-center justify-between"><h2 className="font-display text-lg font-medium">{title}</h2><button onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 hover:bg-white/10"><X className="h-5 w-5" /></button></div>
        {children}
      </div>
    </div>
  );
}

export const Label = ({ children, hint, htmlFor }: { children: React.ReactNode; hint?: string; htmlFor?: string }) => (
  <label htmlFor={htmlFor} className="mb-1 block text-xs font-medium text-white/60">{children}{hint && <span className="ml-1.5 font-normal text-white/35">{hint}</span>}</label>
);

export function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)}
      className={clsx("relative h-6 w-11 shrink-0 rounded-full transition disabled:opacity-50", checked ? "bg-violet-600" : "bg-white/15")}>
      <span className={clsx("absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all", checked ? "left-[1.375rem]" : "left-0.5")} />
    </button>
  );
}

export function PageState({ loading, error, onRetry, children }: { loading: boolean; error: string | null; onRetry: () => void; children: React.ReactNode }) {
  if (error) return <Card className="text-center"><p className="text-sm text-white/70">{error}</p><Btn variant="ghost" className="mt-3" onClick={onRetry}>Try again</Btn></Card>;
  if (loading) return <div className="grid h-40 place-items-center"><Loader2 className="h-6 w-6 animate-spin text-white/40" /></div>;
  return <>{children}</>;
}

export const Empty = ({ text }: { text: string }) => <div className="py-10 text-center text-sm text-white/45">{text}</div>;

export function Pager({ page, total, size, onPage }: { page: number; total: number; size: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / size));
  return (
    <div className="mt-4 flex items-center justify-between text-sm text-white/60">
      <span>{total} total</span>
      <div className="flex items-center gap-2"><Btn variant="ghost" disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</Btn><span>{page} / {pages}</span><Btn variant="ghost" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</Btn></div>
    </div>
  );
}
