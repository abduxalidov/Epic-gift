"use client";
import { useState } from "react";
import { Lock } from "lucide-react";
import { adm } from "@/lib/admin-client";
import { Btn } from "@/components/admin/ui";

export default function AdminLogin() {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    try { await adm("/auth/login", { body: { username: u, password: p } }); window.location.href = "/admin"; }
    catch (x) { setErr(x instanceof Error ? x.message : "Couldn't sign in."); setBusy(false); }
  }
  return (
    <div className="grid min-h-dvh place-items-center bg-night-950 px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-white/10 bg-white/[.04] p-7">
        <div className="mb-5 grid h-12 w-12 place-items-center rounded-2xl bg-violet-600"><Lock className="h-5 w-5" /></div>
        <h1 className="font-display text-xl font-medium">Admin sign in</h1>
        <p className="mt-1 text-sm text-white/50">Staff accounts only.</p>
        <label htmlFor="u" className="mt-5 block text-xs font-medium text-white/60">Username</label>
        <input id="u" className="field mt-1" autoComplete="username" value={u} onChange={(e) => setU(e.target.value)} required />
        <label htmlFor="p" className="mt-3 block text-xs font-medium text-white/60">Password</label>
        <input id="p" type="password" className="field mt-1" autoComplete="current-password" value={p} onChange={(e) => setP(e.target.value)} required />
        {err && <p role="alert" className="mt-3 text-sm text-rose-400">{err}</p>}
        <Btn type="submit" loading={busy} className="mt-5 w-full">Sign in</Btn>
      </form>
    </div>
  );
}
