"use client";
import { useState } from "react";
import { Search } from "lucide-react";
import { Btn, Card, Empty, Label, Modal, PageState, Pager, canWrite, useAdminUi } from "@/components/admin/ui";
import { adm, money, useAdm, when } from "@/lib/admin-client";
import { TX_LABEL } from "@/lib/client";

type Row = { id: string; telegramId: string; username: string | null; firstName: string; balance: number; isBanned: boolean; createdAt: string; gifts: number; invited: number };

export default function UsersAdmin() {
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const [banned, setBanned] = useState(false);
  const [page, setPage] = useState(1);
  const [sel, setSel] = useState<string | null>(null);
  const qs = `/users?page=${page}${term ? `&q=${encodeURIComponent(term)}` : ""}${banned ? "&banned=1" : ""}`;
  const { data, error, loading, reload } = useAdm<{ total: number; pageSize: number; users: Row[] }>(qs);

  return (
    <div>
      <h1 className="mb-5 font-display text-2xl font-medium">Users</h1>
      <form onSubmit={(e) => { e.preventDefault(); setPage(1); setTerm(q.trim()); }} className="mb-4 flex flex-wrap gap-2">
        <div className="relative min-w-[14rem] flex-1"><Search className="absolute left-3 top-3 h-4 w-4 text-white/35" /><input aria-label="Search users" className="field pl-9" placeholder="Name, @username or Telegram ID" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <label className="flex items-center gap-2 rounded-xl border border-white/10 px-3 text-sm"><input type="checkbox" checked={banned} onChange={(e) => { setBanned(e.target.checked); setPage(1); }} /> Banned only</label>
        <Btn type="submit">Search</Btn>
      </form>
      <PageState loading={loading} error={error} onRetry={reload}>
        <Card className="overflow-x-auto p-0">
          {data?.users.length ? (
            <table className="w-full text-left text-sm">
              <thead className="border-b border-white/10 text-xs text-white/45"><tr>{["Player", "Balance", "Gifts", "Invited", "Joined", "Status", ""].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-white/5">
                {data.users.map((u) => (
                  <tr key={u.id} className="hover:bg-white/[.03]">
                    <td className="px-4 py-3"><p className="font-semibold">{u.firstName}</p><p className="text-xs text-white/40">{u.username ? `@${u.username} · ` : ""}{u.telegramId}</p></td>
                    <td className="px-4 py-3">{money(u.balance)}</td><td className="px-4 py-3">{u.gifts}</td><td className="px-4 py-3">{u.invited}</td>
                    <td className="px-4 py-3 text-white/60">{when(u.createdAt)}</td>
                    <td className="px-4 py-3"><span className={u.isBanned ? "text-rose-400" : "text-emerald-400"}>{u.isBanned ? "Banned" : "Active"}</span></td>
                    <td className="px-4 py-3 text-right"><Btn variant="ghost" onClick={() => setSel(u.id)}>Manage</Btn></td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <Empty text="No players match this search." />}
        </Card>
        {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
      </PageState>
      <UserModal id={sel} onClose={() => setSel(null)} onChanged={reload} />
    </div>
  );
}

function UserModal({ id, onClose, onChanged }: { id: string | null; onClose: () => void; onChanged: () => void }) {
  const { role, notify } = useAdminUi();
  const { data, error, loading, reload } = useAdm<any>(id ? `/users/${id}` : null);
  const [reason, setReason] = useState("");
  const [mode, setMode] = useState<"add" | "set">("add");
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);

  async function patch(body: unknown, ok: string) {
    setBusy(true);
    try { await adm(`/users/${id}`, { method: "PATCH", body }); notify(ok); reload(); onChanged(); }
    catch (e) { notify(e instanceof Error ? e.message : "Couldn't update", "err"); } finally { setBusy(false); }
  }
  const u = data?.user;
  return (
    <Modal open={!!id} onClose={onClose} title={u ? `${u.firstName}${u.username ? ` (@${u.username})` : ""}` : "Player"} wide>
      <PageState loading={loading && !data} error={error} onRetry={reload}>
        {u && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 text-sm">
              {[["Balance", money(u.balance)], ["Gifts held", u._count.inventory], ["Friends invited", u._count.referralsMade], ["Rocket rounds", u._count.rocketRounds]].map(([l, v]) => <div key={l as string} className="rounded-xl bg-white/5 p-3"><p className="text-lg font-bold">{v}</p><p className="text-xs text-white/45">{l}</p></div>)}
            </div>
            <p className="text-xs text-white/45">Telegram ID {u.telegramId} · joined {when(u.createdAt)} · last seen {when(u.lastSeenAt)}{u.referredBy ? ` · invited by ${u.referredBy.firstName}` : ""}</p>

            {canWrite(role) && (
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <h3 className="mb-3 text-sm font-semibold">{u.isBanned ? "Account is banned" : "Ban player"}</h3>
                  {u.isBanned && u.banReason && <p className="mb-2 text-xs text-white/50">Reason: {u.banReason}</p>}
                  {!u.isBanned && <><Label htmlFor="br">Reason</Label><input id="br" className="field mb-3" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} /></>}
                  <Btn variant={u.isBanned ? "primary" : "danger"} loading={busy} onClick={() => patch({ isBanned: !u.isBanned, banReason: reason || null }, u.isBanned ? "Player unbanned" : "Player banned")}>{u.isBanned ? "Unban" : "Ban"}</Btn>
                </Card>
                {role === "SUPER_ADMIN" && (
                  <Card>
                    <h3 className="mb-3 text-sm font-semibold">Edit balance</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <select aria-label="Mode" className="field" value={mode} onChange={(e) => setMode(e.target.value as "add" | "set")}><option value="add">Add / remove</option><option value="set">Set to</option></select>
                      <input aria-label="Amount" className="field col-span-2" type="number" placeholder={mode === "add" ? "e.g. 100 or -50" : "New balance"} value={amount} onChange={(e) => setAmount(e.target.value)} />
                    </div>
                    <input aria-label="Reason" className="field mt-2" placeholder="Reason (saved in the log)" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} />
                    <Btn className="mt-3" loading={busy} disabled={amount === "" || reason.trim().length < 3} onClick={() => patch({ balance: { mode, amount: Number(amount), reason } }, "Balance updated").then(() => { setAmount(""); setReason(""); })}>Apply</Btn>
                  </Card>
                )}
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <h3 className="mb-2 text-sm font-semibold">Recent transactions</h3>
                {data.transactions.length === 0 ? <p className="py-4 text-sm text-white/40">No transactions.</p> : <ul className="max-h-60 divide-y divide-white/5 overflow-y-auto text-sm">{data.transactions.map((t: any) => <li key={t.id} className="flex justify-between py-1.5"><span>{TX_LABEL[t.type] ?? t.type}<span className="ml-2 text-xs text-white/35">{when(t.createdAt)}</span></span><b className={t.amount > 0 ? "text-emerald-400" : t.amount < 0 ? "text-rose-400" : "text-white/40"}>{t.amount > 0 ? "+" : ""}{money(t.amount)}</b></li>)}</ul>}
              </Card>
              <Card>
                <h3 className="mb-2 text-sm font-semibold">Gifts held</h3>
                {data.inventory.length === 0 ? <p className="py-4 text-sm text-white/40">No gifts.</p> : <ul className="max-h-60 divide-y divide-white/5 overflow-y-auto text-sm">{data.inventory.map((i: any) => <li key={i.id} className="py-1.5">{i.gift.emoji} {i.gift.name} <span className="text-xs text-white/35">· {i.gift.rarity.toLowerCase()}</span></li>)}</ul>}
              </Card>
            </div>
          </div>
        )}
      </PageState>
    </Modal>
  );
}
