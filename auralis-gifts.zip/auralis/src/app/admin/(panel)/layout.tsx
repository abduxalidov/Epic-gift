"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { BarChart3, CalendarDays, Gift, LogOut, Receipt, Settings, Sparkles, Ticket, Users } from "lucide-react";
import { adm } from "@/lib/admin-client";
import { ToastHost } from "@/components/admin/ui";

const NAV = [
  { href: "/admin", label: "Overview", Icon: BarChart3 },
  { href: "/admin/users", label: "Users", Icon: Users },
  { href: "/admin/gifts", label: "Gifts", Icon: Gift },
  { href: "/admin/promos", label: "Promo codes", Icon: Ticket },
  { href: "/admin/daily", label: "Daily rewards", Icon: CalendarDays },
  { href: "/admin/events", label: "Events", Icon: Sparkles },
  { href: "/admin/transactions", label: "Transactions", Icon: Receipt },
  { href: "/admin/settings", label: "Settings", Icon: Settings },
];

export default function PanelLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const [me, setMe] = useState<{ username: string; role: "SUPER_ADMIN" | "MANAGER" | "SUPPORT" } | null>(null);
  useEffect(() => { adm<{ admin: NonNullable<typeof me> }>("/auth/me").then((r) => setMe(r.admin)).catch(() => {}); }, []);
  if (!me) return <div className="grid min-h-dvh place-items-center bg-night-950 text-sm text-white/40">Loading…</div>;

  return (
    <ToastHost role={me.role}>
      <div className="min-h-dvh bg-night-950 md:flex">
        <aside className="border-b border-white/10 md:sticky md:top-0 md:h-dvh md:w-60 md:shrink-0 md:border-b-0 md:border-r">
          <div className="flex items-center justify-between px-4 py-4 md:block">
            <p className="font-display text-lg font-medium">Auralis admin</p>
            <p className="hidden text-xs text-white/45 md:mt-1 md:block">{me.username} · {me.role.replace("_", " ").toLowerCase()}</p>
          </div>
          <nav aria-label="Admin" className="no-scrollbar flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:overflow-visible">
            {NAV.map(({ href, label, Icon }) => {
              const active = href === "/admin" ? path === "/admin" : path.startsWith(href);
              return <Link key={href} href={href} aria-current={active ? "page" : undefined} className={clsx("flex shrink-0 items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium", active ? "bg-violet-600 text-white" : "text-white/60 hover:bg-white/5")}><Icon className="h-4 w-4" />{label}</Link>;
            })}
            <button onClick={async () => { await adm("/auth/logout", { method: "POST", body: {} }); window.location.href = "/admin/login"; }} className="flex shrink-0 items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-white/60 hover:bg-white/5 md:mt-4"><LogOut className="h-4 w-4" />Sign out</button>
          </nav>
        </aside>
        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>
    </ToastHost>
  );
}
