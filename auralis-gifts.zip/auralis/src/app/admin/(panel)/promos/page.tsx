"use client";
import { CrudPage } from "@/components/admin/CrudPage";
import { money, when } from "@/lib/admin-client";

export default function PromosAdmin() {
  return (
    <CrudPage
      title="Promo codes" itemName="Promo code" endpoint="/promos"
      defaults={{ code: "", rewardPoints: 100, maxUses: "", expiresAt: "", isActive: true }}
      fields={[
        { key: "code", label: "Code", type: "text", hint: "letters, numbers, - and _", max: 32 },
        { key: "rewardPoints", label: "Reward (demo points)", type: "number", min: 1 },
        { key: "maxUses", label: "Usage limit", type: "number", nullable: true, hint: "empty = unlimited", min: 1 },
        { key: "expiresAt", label: "Expires", type: "datetime", hint: "empty = never" },
        { key: "isActive", label: "Active", type: "bool" },
      ]}
      columns={[
        { label: "Code", render: (p) => <span className="font-mono font-semibold tracking-wider">{p.code}</span> },
        { label: "Reward", render: (p) => money(p.rewardPoints) },
        { label: "Used", render: (p) => `${money(p.usedCount)}${p.maxUses ? ` / ${money(p.maxUses)}` : ""}` },
        { label: "Expires", render: (p) => (p.expiresAt ? when(p.expiresAt) : "Never") },
        { label: "Status", render: (p) => { const dead = p.expiresAt && new Date(p.expiresAt) < new Date(); const full = p.maxUses && p.usedCount >= p.maxUses; return <span className={p.isActive && !dead && !full ? "text-emerald-400" : "text-white/40"}>{!p.isActive ? "Off" : dead ? "Expired" : full ? "Used up" : "Live"}</span>; } },
      ]}
    />
  );
}
