"use client";
import { Card, PageState } from "@/components/admin/ui";
import { money, useAdm, when } from "@/lib/admin-client";
import { RARITY, RARITY_ORDER } from "@/lib/rarity";
import { TX_LABEL } from "@/lib/client";

type Stats = {
  users: number; new24: number; active24: number; banned: number; pointsInCirculation: number; giftsHeld: number; redemptions: number; referrals: number;
  rocket: { rounds: number; staked: number; paidOut: number };
  signups: { day: string; count: number }[]; rarity: Record<string, number>;
  recent: { id: string; type: string; amount: number; at: string; user: string }[];
};

export default function Overview() {
  const { data, error, loading, reload } = useAdm<Stats>("/stats");
  return (
    <div>
      <h1 className="mb-5 font-display text-2xl font-medium">Overview</h1>
      <PageState loading={loading} error={error} onRetry={reload}>
        {data && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              {([["Players", data.users], ["New in 24h", data.new24], ["Active in 24h", data.active24], ["Banned", data.banned], ["Points in circulation", data.pointsInCirculation], ["Gifts held", data.giftsHeld], ["Promo redemptions", data.redemptions], ["Referrals", data.referrals]] as [string, number][]).map(([l, v]) => (
                <Card key={l}><p className="font-display text-2xl">{money(v)}</p><p className="mt-1 text-xs text-white/50">{l}</p></Card>
              ))}
            </div>
            <div className="grid gap-5 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <h2 className="mb-4 text-sm font-semibold">New players, last 14 days</h2>
                {data.signups.length === 0 ? <p className="py-8 text-center text-sm text-white/40">No sign-ups in this period.</p> : (
                  <div className="flex h-36 items-end gap-1.5">
                    {data.signups.map((s) => { const max = Math.max(...data.signups.map((x) => x.count)); return (
                      <div key={s.day} className="group flex flex-1 flex-col items-center justify-end gap-1" title={`${new Date(s.day).toLocaleDateString()}: ${s.count}`}>
                        <span className="text-[10px] text-white/50">{s.count}</span>
                        <div className="w-full rounded-t-md bg-gradient-to-t from-violet-700 to-indigo-400" style={{ height: `${Math.max(6, (s.count / max) * 100)}%` }} />
                      </div>
                    ); })}
                  </div>
                )}
              </Card>
              <Card>
                <h2 className="mb-4 text-sm font-semibold">Gifts held by rarity</h2>
                <div className="space-y-3">
                  {RARITY_ORDER.map((r) => (
                    <div key={r}><div className="flex justify-between text-xs"><span style={{ color: RARITY[r].color }}>{RARITY[r].label}</span><span>{money(data.rarity[r] ?? 0)}</span></div>
                      <div className="mt-1 h-1.5 rounded-full bg-white/10"><div className="h-full rounded-full" style={{ width: `${data.giftsHeld ? ((data.rarity[r] ?? 0) / data.giftsHeld) * 100 : 0}%`, background: RARITY[r].color }} /></div></div>
                  ))}
                </div>
              </Card>
            </div>
            <div className="grid gap-5 lg:grid-cols-3">
              <Card>
                <h2 className="mb-3 text-sm font-semibold">Rocket demo</h2>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between"><dt className="text-white/50">Rounds</dt><dd>{money(data.rocket.rounds)}</dd></div>
                  <div className="flex justify-between"><dt className="text-white/50">Points staked</dt><dd>{money(data.rocket.staked)}</dd></div>
                  <div className="flex justify-between"><dt className="text-white/50">Points paid out</dt><dd>{money(data.rocket.paidOut)}</dd></div>
                </dl>
              </Card>
              <Card className="lg:col-span-2">
                <h2 className="mb-3 text-sm font-semibold">Latest activity</h2>
                {data.recent.length === 0 ? <p className="py-6 text-center text-sm text-white/40">Nothing has happened yet.</p> : (
                  <ul className="divide-y divide-white/5 text-sm">
                    {data.recent.map((t) => <li key={t.id} className="flex items-center justify-between py-2"><span>{t.user} <span className="text-white/45">· {TX_LABEL[t.type] ?? t.type}</span></span><span className="flex gap-3"><b className={t.amount > 0 ? "text-emerald-400" : t.amount < 0 ? "text-rose-400" : "text-white/40"}>{t.amount > 0 ? "+" : ""}{money(t.amount)}</b><span className="text-xs text-white/35">{when(t.at)}</span></span></li>)}
                  </ul>
                )}
              </Card>
            </div>
          </div>
        )}
      </PageState>
    </div>
  );
}
