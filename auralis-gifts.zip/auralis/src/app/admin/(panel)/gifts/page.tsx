"use client";
import { CrudPage } from "@/components/admin/CrudPage";
import { RARITY, RARITY_ORDER, type RarityKey } from "@/lib/rarity";
import { money } from "@/lib/admin-client";

export default function GiftsAdmin() {
  return (
    <CrudPage
      title="Gifts" itemName="Gift" endpoint="/gifts"
      defaults={{ name: "", slug: "", emoji: "🎁", description: "", imageUrl: null, rarity: "COMMON", exchangeValue: 10, boxWeight: 100, isActive: true, isFeatured: false }}
      fields={[
        { key: "name", label: "Name", type: "text", max: 60 },
        { key: "slug", label: "Slug", type: "text", hint: "lowercase-with-dashes", max: 40 },
        { key: "emoji", label: "Emoji", type: "text", hint: "shown when there's no image", max: 8 },
        { key: "rarity", label: "Rarity", type: "select", options: RARITY_ORDER.map((r) => [r, RARITY[r].label]) },
        { key: "exchangeValue", label: "Exchange value", type: "number", hint: "points", min: 0 },
        { key: "boxWeight", label: "Box weight", type: "number", hint: "higher = more common, 0 = never drops", min: 0 },
        { key: "description", label: "Description", type: "textarea", max: 300 },
        { key: "imageUrl", label: "Image", type: "image" },
        { key: "isActive", label: "Active (can drop and be shown)", type: "bool" },
        { key: "isFeatured", label: "Featured on home", type: "bool" },
      ]}
      columns={[
        { label: "Gift", render: (g) => <div className="flex items-center gap-3">{g.imageUrl ? <img src={g.imageUrl} alt="" className="h-9 w-9 rounded-lg object-contain" /> : <span className="grid h-9 w-9 place-items-center rounded-lg bg-white/5 text-xl">{g.emoji}</span>}<div><p className="font-semibold">{g.name}</p><p className="text-xs text-white/40">{g.slug}</p></div></div> },
        { label: "Rarity", render: (g) => <span style={{ color: RARITY[g.rarity as RarityKey].color }}>{RARITY[g.rarity as RarityKey].label}</span> },
        { label: "Value", render: (g) => money(g.exchangeValue) },
        { label: "Weight", render: (g) => money(g.boxWeight) },
        { label: "Owned", render: (g) => money(g._count?.inventory ?? 0) },
        { label: "Status", render: (g) => <span className={g.isActive ? "text-emerald-400" : "text-white/40"}>{g.isActive ? "Active" : "Off"}{g.isFeatured ? " · featured" : ""}</span> },
      ]}
    />
  );
}
