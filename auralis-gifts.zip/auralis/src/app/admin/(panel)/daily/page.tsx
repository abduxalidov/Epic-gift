"use client";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Btn, Card, PageState, Toggle, canWrite, useAdminUi } from "@/components/admin/ui";
import { adm, useAdm } from "@/lib/admin-client";

type R = { day: number; points: number; giftId: string | null; isActive: boolean };

export default function DailyAdmin() {
  const { role, notify } = useAdminUi();
  const { data, error, loading, reload } = useAdm<{ rewards: R[]; gifts: { id: string; name: string; emoji: string }[] }>("/daily");
  const [rows, setRows] = useState<R[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data) setRows(data.rewards.map(({ day, points, giftId, isActive }) => ({ day, points, giftId, isActive }))); }, [data]);
  const write = canWrite(role);
  const upd = (i: number, p: Partial<R>) => setRows((r) => r.map((x, j) => (j === i ? { ...x, ...p } : x)));

  async function save() {
    setBusy(true);
    try { await adm("/daily", { method: "PUT", body: { rewards: rows } }); notify("Daily rewards saved"); reload(); }
    catch (e) { notify(e instanceof Error ? e.message : "Couldn't save", "err"); } finally { setBusy(false); }
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-medium">Daily rewards</h1>
      <p className="mb-5 text-sm text-white/50">Players move through the active days in order, then the cycle repeats. Missing a day resets their streak (timing is in Settings).</p>
      <PageState loading={loading} error={error} onRetry={reload}>
        <Card className="space-y-3">
          {rows.map((r, i) => (
            <div key={i} className="grid grid-cols-2 items-end gap-3 rounded-xl bg-white/[.03] p-3 sm:grid-cols-[5rem_1fr_1.5fr_auto_auto]">
              <div><label className="mb-1 block text-xs text-white/50" htmlFor={`d${i}`}>Day</label><input id={`d${i}`} className="field" type="number" min={1} max={30} disabled={!write} value={r.day} onChange={(e) => upd(i, { day: Number(e.target.value) })} /></div>
              <div><label className="mb-1 block text-xs text-white/50" htmlFor={`p${i}`}>Points</label><input id={`p${i}`} className="field" type="number" min={0} disabled={!write} value={r.points} onChange={(e) => upd(i, { points: Number(e.target.value) })} /></div>
              <div className="col-span-2 sm:col-span-1"><label className="mb-1 block text-xs text-white/50" htmlFor={`g${i}`}>Bonus gift</label>
                <select id={`g${i}`} className="field" disabled={!write} value={r.giftId ?? ""} onChange={(e) => upd(i, { giftId: e.target.value || null })}><option value="">None</option>{data?.gifts.map((g) => <option key={g.id} value={g.id}>{g.emoji} {g.name}</option>)}</select></div>
              <div className="flex items-center gap-2 pb-2"><Toggle checked={r.isActive} disabled={!write} onChange={(v) => upd(i, { isActive: v })} label={`Day ${r.day} active`} /><span className="text-xs text-white/50">Active</span></div>
              {write && <button aria-label="Remove day" onClick={() => setRows((x) => x.filter((_, j) => j !== i))} className="justify-self-end rounded-lg p-2 text-rose-400 hover:bg-white/10"><Trash2 className="h-4 w-4" /></button>}
            </div>
          ))}
          {write && (
            <div className="flex justify-between pt-2">
              <Btn variant="ghost" onClick={() => setRows((r) => [...r, { day: Math.max(0, ...r.map((x) => x.day)) + 1, points: 50, giftId: null, isActive: true }])}><Plus className="h-4 w-4" /> Add day</Btn>
              <Btn loading={busy} disabled={rows.length === 0} onClick={save}>Save rewards</Btn>
            </div>
          )}
        </Card>
      </PageState>
    </div>
  );
}
