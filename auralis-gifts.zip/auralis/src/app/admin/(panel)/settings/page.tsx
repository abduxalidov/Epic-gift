"use client";
import { useEffect, useMemo, useState } from "react";
import { Btn, Card, Label, PageState, Toggle, useAdminUi } from "@/components/admin/ui";
import { adm, useAdm } from "@/lib/admin-client";

type S = { key: string; group: string; label: string; description?: string; type: "boolean" | "int" | "float" | "string"; value: boolean | number | string; min?: number; max?: number };

export default function SettingsAdmin() {
  const { role, notify } = useAdminUi();
  const { data, error, loading, reload } = useAdm<{ settings: S[] }>("/settings");
  const [vals, setVals] = useState<Record<string, boolean | number | string>>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data) setVals(Object.fromEntries(data.settings.map((s) => [s.key, s.value]))); }, [data]);
  const groups = useMemo(() => { const m = new Map<string, S[]>(); for (const s of data?.settings ?? []) m.set(s.group, [...(m.get(s.group) ?? []), s]); return [...m]; }, [data]);
  const dirty = data?.settings.filter((s) => vals[s.key] !== s.value).map((s) => s.key) ?? [];
  const canEdit = role === "SUPER_ADMIN";

  async function save() {
    setBusy(true);
    try {
      await adm("/settings", { method: "PUT", body: { values: Object.fromEntries(dirty.map((k) => [k, vals[k]])) } });
      notify("Settings saved. They apply within a few seconds."); reload();
    } catch (e) { notify(e instanceof Error ? e.message : "Couldn't save", "err"); } finally { setBusy(false); }
  }

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <h1 className="font-display text-2xl font-medium">Settings</h1>
        {canEdit && <Btn loading={busy} disabled={dirty.length === 0} onClick={save}>Save {dirty.length ? `${dirty.length} change${dirty.length > 1 ? "s" : ""}` : "changes"}</Btn>}
      </div>
      {!canEdit && <p className="mb-4 rounded-xl bg-amber-400/10 p-3 text-sm text-amber-200">Only super admins can change settings. You're viewing them read-only.</p>}
      <PageState loading={loading} error={error} onRetry={reload}>
        <div className="space-y-5">
          {groups.map(([g, items]) => (
            <Card key={g}>
              <h2 className="mb-4 text-sm font-semibold">{g}</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {items.map((s) => s.type === "boolean" ? (
                  <div key={s.key} className="flex items-center justify-between gap-3 rounded-xl bg-white/[.04] px-3.5 py-3">
                    <div><p className="text-sm">{s.label}</p>{s.description && <p className="text-xs text-white/40">{s.description}</p>}</div>
                    <Toggle checked={!!vals[s.key]} disabled={!canEdit} onChange={(v) => setVals((x) => ({ ...x, [s.key]: v }))} label={s.label} />
                  </div>
                ) : (
                  <div key={s.key}>
                    <Label htmlFor={s.key} hint={s.min !== undefined ? `${s.min}–${s.max}` : undefined}>{s.label}</Label>
                    <input id={s.key} className="field" disabled={!canEdit} type={s.type === "string" ? "text" : "number"} step={s.type === "float" ? "any" : 1} value={String(vals[s.key] ?? "")}
                      onChange={(e) => setVals((x) => ({ ...x, [s.key]: s.type === "string" ? e.target.value : e.target.value === "" ? "" : Number(e.target.value) }))} />
                    {s.description && <p className="mt-1 text-xs text-white/40">{s.description}</p>}
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </PageState>
    </div>
  );
}
