"use client";
import { CrudPage } from "@/components/admin/CrudPage";
import { when } from "@/lib/admin-client";

export default function EventsAdmin() {
  return (
    <CrudPage
      title="Special events" itemName="Event" endpoint="/events"
      defaults={{ title: "", description: "", emoji: "✨", endsAt: "", isActive: true }}
      fields={[
        { key: "title", label: "Title", type: "text", max: 60 },
        { key: "emoji", label: "Emoji", type: "text", max: 8 },
        { key: "description", label: "Description", type: "textarea", max: 200 },
        { key: "endsAt", label: "Ends", type: "datetime", hint: "empty = no end" },
        { key: "isActive", label: "Show on home screen", type: "bool" },
      ]}
      columns={[
        { label: "Event", render: (e) => <span><span className="mr-2 text-lg">{e.emoji}</span><b>{e.title}</b></span> },
        { label: "Description", render: (e) => <span className="text-white/60">{e.description}</span> },
        { label: "Ends", render: (e) => (e.endsAt ? when(e.endsAt) : "No end") },
        { label: "Status", render: (e) => <span className={e.isActive ? "text-emerald-400" : "text-white/40"}>{e.isActive ? "Live" : "Hidden"}</span> },
      ]}
    />
  );
}
