"use client";
import { useState } from "react";
import { Card, Empty, PageState, Pager } from "@/components/admin/ui";
import { money, useAdm, when } from "@/lib/admin-client";
import { TX_LABEL } from "@/lib/client";

export default function TransactionsAdmin() {
  const [type, setType] = useState("");
  const [page, setPage] = useState(1);
  const { data, error, loading, reload } = useAdm<{ total: number; pageSize: number; transactions: any[] }>(`/transactions?page=${page}${type ? `&type=${type}` : ""}`);
  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-medium">Transactions</h1>
        <select aria-label="Filter by type" className="field w-auto" value={type} onChange={(e) => { setType(e.target.value); setPage(1); }}>
          <option value="">All types</option>{Object.entries(TX_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </select>
      </div>
      <PageState loading={loading} error={error} onRetry={reload}>
        <Card className="overflow-x-auto p-0">
          {data?.transactions.length ? (
            <table className="w-full text-left text-sm">
              <thead className="border-b border-white/10 text-xs text-white/45"><tr>{["When", "Player", "Type", "Amount", "Balance after", "Details"].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-white/5">
                {data.transactions.map((t) => (
                  <tr key={t.id}>
                    <td className="whitespace-nowrap px-4 py-2.5 text-white/60">{when(t.createdAt)}</td>
                    <td className="px-4 py-2.5">{t.user.username ? `@${t.user.username}` : t.user.firstName}</td>
                    <td className="px-4 py-2.5">{TX_LABEL[t.type] ?? t.type}</td>
                    <td className={`px-4 py-2.5 font-bold ${t.amount > 0 ? "text-emerald-400" : t.amount < 0 ? "text-rose-400" : "text-white/40"}`}>{t.amount > 0 ? "+" : ""}{money(t.amount)}</td>
                    <td className="px-4 py-2.5">{money(t.balanceAfter)}</td>
                    <td className="max-w-[16rem] truncate px-4 py-2.5 text-xs text-white/40">{t.meta ? JSON.stringify(t.meta) : ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <Empty text="No transactions found." />}
        </Card>
        {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
      </PageState>
    </div>
  );
}
