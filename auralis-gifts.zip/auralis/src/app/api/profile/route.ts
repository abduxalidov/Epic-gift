import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { publicUser } from "@/lib/users";

export const GET = withUser(async (_req, user) => {
  const [held, ever, ref, tx] = await Promise.all([
    db.inventory.count({ where: { userId: user.id, exchangedAt: null } }),
    db.inventory.count({ where: { userId: user.id } }),
    db.referral.aggregate({ where: { inviterId: user.id }, _count: true, _sum: { rewardPoints: true } }),
    db.transaction.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 40 }),
  ]);
  return json({
    user: publicUser(user),
    stats: { totalGifts: held, totalCollected: ever, invited: ref._count, referralEarnings: ref._sum.rewardPoints ?? 0 },
    transactions: tx.map((t) => ({ id: t.id, type: t.type, amount: t.amount, balanceAfter: t.balanceAfter, at: t.createdAt })),
  });
});
