import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { giftDto } from "@/lib/dto";

/** Full catalog + which gifts this player has collected (virtual collection). */
export const GET = withUser(async (_req, user) => {
  const [gifts, ever, held] = await Promise.all([
    db.gift.findMany({ where: { isActive: true }, orderBy: [{ exchangeValue: "desc" }, { name: "asc" }] }),
    db.inventory.groupBy({ by: ["giftId"], where: { userId: user.id }, _count: true }),
    db.inventory.groupBy({ by: ["giftId"], where: { userId: user.id, exchangedAt: null }, _count: true }),
  ]);
  const collected = new Set(ever.map((e) => e.giftId));
  const heldMap = new Map(held.map((h) => [h.giftId, h._count]));
  return json({ gifts: gifts.map((g) => ({ ...giftDto(g), collected: collected.has(g.id), owned: heldMap.get(g.id) ?? 0 })) });
});
