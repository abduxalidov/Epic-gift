import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyDelta, drawGift, grantGift } from "@/lib/economy";
import { giftDto } from "@/lib/dto";
import { getSetting, requireFeature } from "@/lib/settings";

const body = z.object({ kind: z.enum(["free", "paid"]) });

export const POST = withUser(async (req, user) => {
  const { kind } = body.parse(await readJson(req));

  if (kind === "free") {
    await requireFeature("features.freeBox");
    const cdMs = (await getSetting<number>("freeBox.cooldownHours")) * 3_600_000;
    const out = await db.$transaction(async (tx) => {
      // atomic claim: only one concurrent request can move lastFreeBoxAt forward
      const claim = await tx.user.updateMany({
        where: { id: user.id, OR: [{ lastFreeBoxAt: null }, { lastFreeBoxAt: { lte: new Date(Date.now() - cdMs) } }] },
        data: { lastFreeBoxAt: new Date() },
      });
      if (claim.count === 0) throw new ApiError(429, "Your next free box isn't ready yet.", "cooldown");
      const gift = await drawGift(tx);
      await grantGift(tx, user.id, gift.id, "FREE_BOX");
      const balance = await applyDelta(tx, user.id, 0, "FREE_BOX", { giftId: gift.id });
      return { gift, balance };
    });
    return json({ gift: giftDto(out.gift), balance: out.balance, nextFreeAt: new Date(Date.now() + cdMs).toISOString() });
  }

  await requireFeature("features.paidBox");
  const cost = await getSetting<number>("paidBox.cost");
  const out = await db.$transaction(async (tx) => {
    const balance = await applyDelta(tx, user.id, -cost, "BOX_PURCHASE");
    const gift = await drawGift(tx);
    await grantGift(tx, user.id, gift.id, "PAID_BOX");
    return { gift, balance };
  });
  return json({ gift: giftDto(out.gift), balance: out.balance });
}, 30);
