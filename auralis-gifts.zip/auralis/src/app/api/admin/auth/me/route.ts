import { json } from "@/lib/api-server";
import { withAdmin } from "@/lib/admin-auth";

export const GET = withAdmin("SUPPORT", async (_req, admin) => json({ admin: { username: admin.username, role: admin.role } }));
