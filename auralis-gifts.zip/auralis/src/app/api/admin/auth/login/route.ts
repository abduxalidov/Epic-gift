import bcrypt from "bcryptjs";
import { z } from "zod";
import { ApiError, clientIp, handle, json, rateLimit, readJson } from "@/lib/api-server";
import { db } from "@/lib/db";
import { ADMIN_COOKIE, signAdminToken } from "@/lib/session";

const body = z.object({ username: z.string().min(1).max(64), password: z.string().min(1).max(200) });
// compared against when the username is unknown so response time doesn't reveal valid usernames
const DUMMY = bcrypt.hashSync("not-a-real-password", 10);

export const POST = handle(async (req) => {
  rateLimit(`admin-login:${clientIp(req)}`, 8, 15 * 60_000);
  const { username, password } = body.parse(await readJson(req));
  const admin = await db.admin.findUnique({ where: { username: username.trim().toLowerCase() } });
  const ok = await bcrypt.compare(password, admin?.passwordHash ?? DUMMY);
  if (!admin || !ok) throw new ApiError(401, "Wrong username or password.", "bad_credentials");
  await db.admin.update({ where: { id: admin.id }, data: { lastLoginAt: new Date() } });
  const res = json({ admin: { username: admin.username, role: admin.role } });
  res.cookies.set(ADMIN_COOKIE, await signAdminToken(admin.id), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 8 * 3600 });
  return res;
});
