import { handle, json } from "@/lib/api-server";
import { ADMIN_COOKIE } from "@/lib/session";

export const POST = handle(async () => {
  const res = json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return res;
});
