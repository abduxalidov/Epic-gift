import { Prisma } from "@prisma/client";
import { z } from "zod";
import { json } from "@/lib/api-server";
import { withAdmin } from "@/lib/admin-auth";
import { db } from "@/lib/db";

const q = z.object({ q: z.string().max(64).optional(), page: z.coerce.number().int().min(1).default(1), banned: z.enum(["1"]).optional() });

export const GET = withAdmin("SUPPORT", async (req) => {
  const p = q.parse(Object.fromEntries(req.nextUrl.searchParams));
  const term = p.q?.trim().replace(/^@/, "");
  const where: Prisma.UserWhereInput = {
    ...(p.banned ? { isBanned: true } : {}),
    ...(term ? { OR: [{ username: { contains: term, mode: "insensitive" } }, { firstName: { contains: term, mode: "insensitive" } }, ...(/^\d{1,15}$/.test(term) ? [{ telegramId: BigInt(term) }] : [])] } : {}),
  };
  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({ where, orderBy: { createdAt: "desc" }, skip: (p.page - 1) * 25, take: 25, include: { _count: { select: { inventory: true, referralsMade: true } } } }),
  ]);
  return json({ total, pageSize: 25, users: users.map(({ _count, ...u }) => ({ ...u, gifts: _count.inventory, invited: _count.referralsMade })) });
});
