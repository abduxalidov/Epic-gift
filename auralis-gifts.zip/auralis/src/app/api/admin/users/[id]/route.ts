import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { adminRw } from "@/lib/admin-auth";
import { db } from "@/lib/db";
import { applyDelta } from "@/lib/economy";

const patch = z.object({
  isBanned: z.boolean().optional(),
  banReason: z.string().max(200).nullable().optional(),
  balance: z.object({
    mode: z.enum(["set", "add"]),
    amount: z.number().int().min(-1_000_000_000).max(1_000_000_000),
    reason: z.string().min(3).max(200),
  }).optional(),
});

/** GET = user activity view, PATCH = ban/unban (manager) and balance edits (super admin). */
const handler = adminRw("MANAGER", async (req, admin, ctx) => {
  const { id } = await ctx.params;

  if (req.method === "GET") {
    const user = await db.user.findUnique({
      where: { id },
      include: { referredBy: { select: { firstName: true, username: true } }, _count: { select: { inventory: true, referralsMade: true, promoRedemptions: true, rocketRounds: true } } },
    });
    if (!user) throw new ApiError(404, "User not found.");
    const [transactions, rounds, inventory] = await Promise.all([
      db.transaction.findMany({ where: { userId: id }, orderBy: { createdAt: "desc" }, take: 30 }),
      db.rocketRound.findMany({ where: { userId: id, status: { not: "FLYING" } }, orderBy: { startedAt: "desc" }, take: 10 }),
      db.inventory.findMany({ where: { userId: id, exchangedAt: null }, orderBy: { acquiredAt: "desc" }, take: 20, include: { gift: { select: { name: true, emoji: true, rarity: true } } } }),
    ]);
    return json({ user, transactions, rounds, inventory });
  }

  const b = patch.parse(await readJson(req));
  if (b.balance && admin.role !== "SUPER_ADMIN") throw new ApiError(403, "Only a super admin can edit balances.", "forbidden");
  if (b.balance?.mode === "set" && b.balance.amount < 0) throw new ApiError(400, "A balance can't be negative.");
  const user = await db.$transaction(async (tx) => {
    if (b.isBanned !== undefined) {
      await tx.user.update({ where: { id }, data: { isBanned: b.isBanned, banReason: b.isBanned ? b.banReason ?? null : null } });
    }
    if (b.balance) {
      const cur = await tx.user.findUniqueOrThrow({ where: { id }, select: { balance: true } });
      const delta = b.balance.mode === "set" ? b.balance.amount - cur.balance : b.balance.amount;
      await applyDelta(tx, id, delta, "ADMIN_ADJUST", { adminId: admin.id, admin: admin.username, reason: b.balance.reason });
    }
    return tx.user.findUniqueOrThrow({ where: { id } });
  });
  return json({ user });
});
export const GET = handler, PATCH = handler;
