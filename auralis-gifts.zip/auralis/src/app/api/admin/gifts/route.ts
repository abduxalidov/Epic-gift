import { db } from "@/lib/db";
import { adminCollection } from "@/lib/admin-crud";
import { giftSchema } from "@/lib/admin-schemas";

const { collection } = adminCollection({ delegate: db.gift, schema: giftSchema, orderBy: [{ createdAt: "desc" }], include: { _count: { select: { inventory: true } } } });
export const GET = collection, POST = collection;
