import { db } from "@/lib/db";
import { json } from "@/lib/api-server";
import { adminCollection } from "@/lib/admin-crud";
import { giftSchema } from "@/lib/admin-schemas";

const { item } = adminCollection({
  delegate: db.gift,
  schema: giftSchema,
  // gifts that players already own are retired instead of deleted, so inventories stay intact
  beforeDelete: async (id) => {
    if ((await db.inventory.count({ where: { giftId: id } })) === 0) return null;
    await db.gift.update({ where: { id }, data: { isActive: false, isFeatured: false } });
    return json({ ok: true, retired: true });
  },
});
export const PATCH = item, DELETE = item;
