import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { adminRw } from "@/lib/admin-auth";
import { db } from "@/lib/db";

const body = z.object({
  rewards: z.array(z.object({
    day: z.number().int().min(1).max(30),
    points: z.number().int().min(0).max(1_000_000),
    giftId: z.string().max(40).nullable(),
    isActive: z.boolean(),
  })).min(1).max(30),
});

const handler = adminRw("MANAGER", async (req) => {
  if (req.method === "GET") {
    const [rewards, gifts] = await Promise.all([
      db.dailyReward.findMany({ orderBy: { day: "asc" } }),
      db.gift.findMany({ where: { isActive: true }, select: { id: true, name: true, emoji: true }, orderBy: { name: "asc" } }),
    ]);
    return json({ rewards, gifts });
  }
  const { rewards } = body.parse(await readJson(req));
  if (new Set(rewards.map((r) => r.day)).size !== rewards.length) throw new ApiError(400, "Each day number can only be used once.");
  await db.$transaction([db.dailyReward.deleteMany(), db.dailyReward.createMany({ data: rewards })]);
  return json({ ok: true });
});
export const GET = handler, PUT = handler;
