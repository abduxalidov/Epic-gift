import { db } from "@/lib/db";
import { adminCollection } from "@/lib/admin-crud";
import { eventSchema } from "@/lib/admin-schemas";

const { item } = adminCollection({ delegate: db.event, schema: eventSchema });
export const PATCH = item, DELETE = item;
