import { db } from "@/lib/db";
import { adminCollection } from "@/lib/admin-crud";
import { eventSchema } from "@/lib/admin-schemas";

const { collection } = adminCollection({ delegate: db.event, schema: eventSchema, orderBy: { createdAt: "desc" } });
export const GET = collection, POST = collection;
