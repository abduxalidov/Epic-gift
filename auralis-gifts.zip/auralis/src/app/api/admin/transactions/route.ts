import { Prisma, TxType } from "@prisma/client";
import { z } from "zod";
import { json } from "@/lib/api-server";
import { withAdmin } from "@/lib/admin-auth";
import { db } from "@/lib/db";

const q = z.object({ type: z.nativeEnum(TxType).optional(), userId: z.string().max(40).optional(), page: z.coerce.number().int().min(1).default(1) });

export const GET = withAdmin("SUPPORT", async (req) => {
  const p = q.parse(Object.fromEntries(req.nextUrl.searchParams));
  const where: Prisma.TransactionWhereInput = { ...(p.type ? { type: p.type } : {}), ...(p.userId ? { userId: p.userId } : {}) };
  const [total, rows] = await Promise.all([
    db.transaction.count({ where }),
    db.transaction.findMany({ where, orderBy: { createdAt: "desc" }, skip: (p.page - 1) * 40, take: 40, include: { user: { select: { firstName: true, username: true } } } }),
  ]);
  return json({ total, pageSize: 40, transactions: rows });
});
