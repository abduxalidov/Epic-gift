import { json } from "@/lib/api-server";
import { withAdmin } from "@/lib/admin-auth";
import { db } from "@/lib/db";

export const GET = withAdmin("SUPPORT", async () => {
  const day = new Date(Date.now() - 86_400_000);
  const [users, new24, active24, banned, circulation, held, redemptions, referrals, rounds, bets, wins, signups, recent, byGift, gifts] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { createdAt: { gte: day } } }),
    db.user.count({ where: { lastSeenAt: { gte: day } } }),
    db.user.count({ where: { isBanned: true } }),
    db.user.aggregate({ _sum: { balance: true } }),
    db.inventory.count({ where: { exchangedAt: null } }),
    db.promoRedemption.count(),
    db.referral.count(),
    db.rocketRound.count(),
    db.transaction.aggregate({ where: { type: "ROCKET_BET" }, _sum: { amount: true } }),
    db.transaction.aggregate({ where: { type: "ROCKET_WIN" }, _sum: { amount: true } }),
    db.$queryRaw<{ d: Date; n: bigint }[]>`SELECT date_trunc('day', "createdAt") AS d, count(*) AS n FROM "User" WHERE "createdAt" > now() - interval '14 days' GROUP BY 1 ORDER BY 1`,
    db.transaction.findMany({ orderBy: { createdAt: "desc" }, take: 10, include: { user: { select: { firstName: true, username: true } } } }),
    db.inventory.groupBy({ by: ["giftId"], where: { exchangedAt: null }, _count: true }),
    db.gift.findMany({ select: { id: true, rarity: true } }),
  ]);
  const rarityOf = new Map(gifts.map((g) => [g.id, g.rarity]));
  const rarity: Record<string, number> = { COMMON: 0, RARE: 0, EPIC: 0, LEGENDARY: 0 };
  for (const r of byGift) rarity[rarityOf.get(r.giftId) ?? "COMMON"] += r._count;
  return json({
    users, new24, active24, banned, pointsInCirculation: circulation._sum.balance ?? 0, giftsHeld: held, redemptions, referrals,
    rocket: { rounds, staked: -(bets._sum.amount ?? 0), paidOut: wins._sum.amount ?? 0 },
    signups: signups.map((s) => ({ day: s.d, count: Number(s.n) })),
    rarity,
    recent: recent.map((t) => ({ id: t.id, type: t.type, amount: t.amount, at: t.createdAt, user: t.user.username ? `@${t.user.username}` : t.user.firstName })),
  });
});
