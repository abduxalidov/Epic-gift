import { randomBytes } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { ApiError, json } from "@/lib/api-server";
import { withAdmin } from "@/lib/admin-auth";
import { optEnv } from "@/lib/env";

const MAX = 2 * 1024 * 1024;

function sniff(b: Buffer): "png" | "jpg" | "gif" | "webp" | null {
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "png";
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "jpg";
  if (b.subarray(0, 4).toString("ascii") === "GIF8") return "gif";
  if (b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WEBP") return "webp";
  return null;
}

/** Gift image upload. The type is detected from the bytes, never from the filename; SVG is refused. */
export const POST = withAdmin("MANAGER", async (req) => {
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) throw new ApiError(400, "Choose an image to upload.");
  if (file.size > MAX) throw new ApiError(413, "Images can be up to 2 MB.");
  const buf = Buffer.from(await file.arrayBuffer());
  const ext = sniff(buf);
  if (!ext) throw new ApiError(415, "Use a PNG, JPG, WebP or GIF image.");
  const name = `${randomBytes(16).toString("hex")}.${ext}`;
  const dir = optEnv("UPLOAD_DIR", "./uploads");
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, name), buf);
  return json({ url: `/uploads/${name}` }, { status: 201 });
});
