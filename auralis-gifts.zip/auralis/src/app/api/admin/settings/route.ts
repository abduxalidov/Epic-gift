import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { adminRw } from "@/lib/admin-auth";
import { db } from "@/lib/db";
import { SETTING_DEFS, allSettings, coerceSetting, invalidateSettings } from "@/lib/settings";

const handler = adminRw("SUPER_ADMIN", async (req) => {
  invalidateSettings();
  if (req.method === "GET") {
    const map = await allSettings();
    return json({ settings: SETTING_DEFS.map((d) => ({ ...d, value: map.get(d.key) })) });
  }
  const { values } = z.object({ values: z.record(z.string(), z.unknown()) }).parse(await readJson(req));
  const current = new Map(await allSettings());
  const next = new Map<string, boolean | number | string>();
  for (const [key, raw] of Object.entries(values)) {
    const def = SETTING_DEFS.find((d) => d.key === key);
    if (!def) throw new ApiError(400, `Unknown setting: ${key}`);
    const v = coerceSetting(def, raw);
    next.set(key, v);
    current.set(key, v);
  }
  if ((current.get("rocket.minBet") as number) > (current.get("rocket.maxBet") as number)) throw new ApiError(400, "Minimum bet can't be higher than the maximum bet.");
  await db.$transaction(
    [...next].map(([key, value]) => {
      const d = SETTING_DEFS.find((x) => x.key === key)!;
      return db.appSettings.upsert({ where: { key }, update: { value }, create: { key, value, group: d.group, label: d.label, description: d.description } });
    }),
  );
  invalidateSettings();
  return json({ ok: true });
});
export const GET = handler, PUT = handler;
