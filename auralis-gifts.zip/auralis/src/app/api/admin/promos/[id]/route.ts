import { db } from "@/lib/db";
import { adminCollection } from "@/lib/admin-crud";
import { promoSchema } from "@/lib/admin-schemas";

const { item } = adminCollection({ delegate: db.promoCode, schema: promoSchema });
export const PATCH = item, DELETE = item;
