import { db } from "@/lib/db";
import { adminCollection } from "@/lib/admin-crud";
import { promoSchema } from "@/lib/admin-schemas";

const { collection } = adminCollection({ delegate: db.promoCode, schema: promoSchema, orderBy: { createdAt: "desc" } });
export const GET = collection, POST = collection;
