import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { giftDto } from "@/lib/dto";

export const GET = withUser(async (_req, user) => {
  const items = await db.inventory.findMany({ where: { userId: user.id, exchangedAt: null }, orderBy: { acquiredAt: "desc" }, take: 1000, include: { gift: true } });
  return json({ items: items.map((i) => ({ id: i.id, giftId: i.giftId, source: i.source, acquiredAt: i.acquiredAt, gift: giftDto(i.gift) })) });
});
