import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyDelta } from "@/lib/economy";
import { getSetting, requireFeature } from "@/lib/settings";

const body = z.object({ inventoryId: z.string().min(1).max(40) });

export const POST = withUser(async (req, user) => {
  const { inventoryId } = body.parse(await readJson(req));
  await requireFeature("features.exchange");
  const fee = await getSetting<number>("exchange.feePct");
  const result = await db.$transaction(async (tx) => {
    const item = await tx.inventory.findFirst({ where: { id: inventoryId, userId: user.id, exchangedAt: null }, include: { gift: true } });
    if (!item) throw new ApiError(404, "That gift is no longer in your inventory.", "not_found");
    const claimed = await tx.inventory.updateMany({ where: { id: item.id, exchangedAt: null }, data: { exchangedAt: new Date() } });
    if (claimed.count === 0) throw new ApiError(409, "That gift was just exchanged.", "conflict");
    const points = Math.floor((item.gift.exchangeValue * (100 - fee)) / 100);
    const balance = await applyDelta(tx, user.id, points, "GIFT_EXCHANGE", { giftId: item.giftId, inventoryId: item.id });
    return { points, balance };
  });
  return json(result);
});
