import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { giftDto } from "@/lib/dto";

export const GET = withUser(async (_req, user) => {
  const rows = await db.inventory.findMany({ where: { userId: user.id }, orderBy: { acquiredAt: "desc" }, take: 100, include: { gift: true } });
  return json({ history: rows.map((i) => ({ id: i.id, source: i.source, acquiredAt: i.acquiredAt, exchangedAt: i.exchangedAt, gift: giftDto(i.gift) })) });
});
