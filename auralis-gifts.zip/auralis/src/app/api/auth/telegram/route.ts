import { z } from "zod";
import { ApiError, clientIp, handle, json, rateLimit, readJson } from "@/lib/api-server";
import { env } from "@/lib/env";
import { signUserToken } from "@/lib/session";
import { verifyInitData } from "@/lib/telegram";
import { publicUser, registerOrSync } from "@/lib/users";

export const POST = handle(async (req) => {
  rateLimit(`auth:${clientIp(req)}`, 30, 60_000);
  const { initData } = z.object({ initData: z.string().min(10).max(4096) }).parse(await readJson(req));
  const verified = verifyInitData(initData, env("TELEGRAM_BOT_TOKEN"));
  if (!verified) throw new ApiError(401, "Telegram sign-in could not be verified. Reopen the app from the bot.", "bad_init_data");
  const { user, isNew } = await registerOrSync(verified.user, verified.startParam);
  if (user.isBanned) throw new ApiError(403, "This account is suspended.", "banned");
  return json({ token: await signUserToken(user.id), user: publicUser(user), isNew });
});
