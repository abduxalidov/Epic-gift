import { ApiError, handle, json } from "@/lib/api-server";
import { signUserToken } from "@/lib/session";
import { publicUser, registerOrSync } from "@/lib/users";

/** Local browser testing only. Hard-disabled in production builds. */
export const POST = handle(async (req) => {
  if (process.env.NODE_ENV === "production" || process.env.ALLOW_DEV_LOGIN !== "true") throw new ApiError(404, "Not found.");
  const ref = req.nextUrl.searchParams.get("ref") ?? undefined;
  const { user, isNew } = await registerOrSync({ id: 900001, first_name: "Dev", last_name: "Player", username: "dev_player" }, ref);
  return json({ token: await signUserToken(user.id), user: publicUser(user), isNew });
});
