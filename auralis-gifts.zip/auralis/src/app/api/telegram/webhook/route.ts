import { json, handle, ApiError } from "@/lib/api-server";
import { env } from "@/lib/env";
import { getSetting } from "@/lib/settings";
import { appUrl, tg, TgUser } from "@/lib/telegram";
import { registerOrSync } from "@/lib/users";

type Update = { message?: { text?: string; chat: { id: number }; from?: TgUser } };

const openButton = (label: string) => ({ inline_keyboard: [[{ text: label, web_app: { url: appUrl() } }]] });

export const POST = handle(async (req) => {
  if (req.headers.get("x-telegram-bot-api-secret-token") !== env("TELEGRAM_WEBHOOK_SECRET")) throw new ApiError(401, "Unauthorized", "unauthorized");
  const msg = ((await req.json().catch(() => ({}))) as Update).message;
  if (!msg?.text || !msg.from) return json({ ok: true });

  const [rawCmd, arg] = msg.text.trim().split(/\s+/, 2);
  const cmd = rawCmd.split("@")[0].toLowerCase();
  const name = await getSetting<string>("app.name");

  if (cmd === "/start") {
    // Registers the player and applies a referral deep link: t.me/<bot>?start=ref_CODE
    const { user, isNew } = await registerOrSync(msg.from, arg);
    if (user.isBanned) {
      await tg("sendMessage", { chat_id: msg.chat.id, text: "This account is suspended." });
    } else {
      await tg("sendMessage", {
        chat_id: msg.chat.id,
        text: isNew
          ? `Welcome to ${name}, ${user.firstName}! 🎁\nYour account is ready with ${user.balance} demo points. Tap the button to open your gifts.`
          : `Welcome back, ${user.firstName}! You have ${user.balance} demo points.`,
        reply_markup: openButton(`Open ${name}`),
      });
    }
  } else if (cmd === "/help") {
    await tg("sendMessage", {
      chat_id: msg.chat.id,
      text: `${name} is a demo gift collection game. Everything uses virtual demo points with no cash value.\n\n/start – open the app\n/help – this message\n\nInside the app: open boxes, collect gifts, claim daily rewards, invite friends and redeem promo codes.`,
      reply_markup: openButton(`Open ${name}`),
    });
  }
  return json({ ok: true });
});
