import { ApiError, json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { dailyState } from "@/lib/daily";
import { db } from "@/lib/db";
import { applyDelta, grantGift } from "@/lib/economy";
import { giftDto } from "@/lib/dto";
import { getSetting, requireFeature } from "@/lib/settings";

export const POST = withUser(async (_req, user) => {
  await requireFeature("features.dailyRewards");
  const [cd, win] = await Promise.all([getSetting<number>("daily.cooldownHours"), getSetting<number>("daily.streakWindowHours")]);
  const out = await db.$transaction(async (tx) => {
    const rewards = await tx.dailyReward.findMany({ where: { isActive: true }, orderBy: { day: "asc" }, include: { gift: true } });
    if (!rewards.length) throw new ApiError(503, "No daily rewards are set up yet.", "empty");
    const fresh = await tx.user.findUniqueOrThrow({ where: { id: user.id } });
    const st = dailyState(fresh, rewards.length, cd, win);
    if (!st.canClaim) throw new ApiError(429, "You already claimed today's reward.", "cooldown");
    // atomic guard against double taps: lastDailyAt must still be what we read
    const guard = await tx.user.updateMany({
      where: { id: user.id, lastDailyAt: fresh.lastDailyAt },
      data: { lastDailyAt: new Date(), dailyStreak: st.nextStreak },
    });
    if (guard.count === 0) throw new ApiError(409, "Already claimed.", "conflict");
    const reward = rewards[st.nextIdx];
    if (reward.gift) await grantGift(tx, user.id, reward.gift.id, "DAILY");
    const balance = await applyDelta(tx, user.id, reward.points, "DAILY_REWARD", { day: reward.day, streak: st.nextStreak, giftId: reward.giftId });
    return { reward, balance, streak: st.nextStreak };
  });
  return json({ points: out.reward.points, gift: out.reward.gift ? giftDto(out.reward.gift) : null, balance: out.balance, streak: out.streak });
}, 20);
