import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { dailyState } from "@/lib/daily";
import { db } from "@/lib/db";
import { giftDto } from "@/lib/dto";
import { allSettings } from "@/lib/settings";
import { publicUser } from "@/lib/users";

const DEMO_NAMES = ["Aiden", "Mira", "Kenji", "Lola", "Zane", "Ravi", "Noor", "Tess"];
const mask = (n: string) => (n.length <= 2 ? n[0] + "•••" : n[0] + "•••" + n.slice(-1));

/** One call that feeds the whole home screen. */
export const GET = withUser(async (_req, user) => {
  const s = await allSettings();
  const num = (k: string) => s.get(k) as number;
  const flag = (k: string) => s.get(k) as boolean;

  const [featured, rewards, real, events, invited] = await Promise.all([
    db.gift.findMany({ where: { isActive: true, isFeatured: true }, take: 10, orderBy: { exchangeValue: "desc" } }),
    db.dailyReward.findMany({ where: { isActive: true }, orderBy: { day: "asc" }, include: { gift: true } }),
    db.inventory.findMany({
      where: { source: { in: ["FREE_BOX", "PAID_BOX"] }, gift: { rarity: { in: ["EPIC", "LEGENDARY"] } } },
      orderBy: { acquiredAt: "desc" }, take: 8, include: { gift: true, user: { select: { firstName: true } } },
    }),
    db.event.findMany({ where: { isActive: true, OR: [{ endsAt: null }, { endsAt: { gt: new Date() } }] }, orderBy: { createdAt: "desc" }, take: 6 }),
    db.referral.count({ where: { inviterId: user.id } }),
  ]);

  // "Latest winners" are demo data: real big pulls first, padded with sample entries.
  const gifts = featured.length ? featured : await db.gift.findMany({ where: { isActive: true }, take: 4 });
  const winners = real.map((r) => ({ name: mask(r.user.firstName), gift: giftDto(r.gift), at: r.acquiredAt, demo: false }));
  for (let i = 0; winners.length < 6 && gifts.length; i++) {
    winners.push({ name: mask(DEMO_NAMES[i % DEMO_NAMES.length]), gift: giftDto(gifts[i % gifts.length]), at: new Date(Date.now() - (i + 1) * 17 * 60_000), demo: true });
  }

  const daily = dailyState(user, rewards.length, num("daily.cooldownHours"), num("daily.streakWindowHours"));
  const freeCd = num("freeBox.cooldownHours") * 3_600_000;
  const freeAt = user.lastFreeBoxAt ? user.lastFreeBoxAt.getTime() + freeCd : 0;

  return json({
    user: publicUser(user),
    config: {
      appName: s.get("app.name"),
      features: {
        freeBox: flag("features.freeBox"), paidBox: flag("features.paidBox"), dailyRewards: flag("features.dailyRewards"),
        referrals: flag("features.referrals"), promo: flag("features.promo"), exchange: flag("features.exchange"), rocket: flag("features.rocket"),
      },
      paidBoxCost: num("paidBox.cost"),
      referral: { inviterReward: num("referral.inviterReward"), inviteeReward: num("referral.inviteeReward") },
    },
    freeBox: { available: Date.now() >= freeAt, nextAt: Date.now() >= freeAt ? null : new Date(freeAt).toISOString() },
    daily: { ...daily, rewards: rewards.map((r) => ({ day: r.day, points: r.points, gift: r.gift ? giftDto(r.gift) : null })) },
    featured: featured.map(giftDto),
    winners,
    events: events.map((e) => ({ id: e.id, title: e.title, description: e.description, emoji: e.emoji, endsAt: e.endsAt })),
    invited,
  });
});
