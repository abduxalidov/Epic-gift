import { Prisma } from "@prisma/client";
import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyDelta } from "@/lib/economy";
import { requireFeature } from "@/lib/settings";

const body = z.object({ code: z.string().trim().min(3).max(32).regex(/^[A-Za-z0-9_-]+$/, "Codes use letters, numbers, - and _.") });

export const POST = withUser(async (req, user) => {
  const { code } = body.parse(await readJson(req));
  await requireFeature("features.promo");
  const out = await db.$transaction(async (tx) => {
    const promo = await tx.promoCode.findUnique({ where: { code: code.toUpperCase() } });
    if (!promo || !promo.isActive) throw new ApiError(404, "That code isn't valid.", "invalid_code");
    if (promo.expiresAt && promo.expiresAt < new Date()) throw new ApiError(410, "That code has expired.", "expired");
    try {
      await tx.promoRedemption.create({ data: { promoId: promo.id, userId: user.id } }); // unique(promoId,userId)
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ApiError(409, "You already used this code.", "already_used");
      throw e;
    }
    const bumped = await tx.promoCode.updateMany({
      where: { id: promo.id, ...(promo.maxUses !== null ? { usedCount: { lt: promo.maxUses } } : {}) },
      data: { usedCount: { increment: 1 } },
    });
    if (bumped.count === 0) throw new ApiError(410, "That code has reached its usage limit.", "limit"); // rolls back the redemption
    const balance = await applyDelta(tx, user.id, promo.rewardPoints, "PROMO", { code: promo.code });
    return { points: promo.rewardPoints, balance };
  });
  return json(out);
}, 15);
