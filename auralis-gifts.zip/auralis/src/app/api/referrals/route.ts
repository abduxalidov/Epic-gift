import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getSetting, requireFeature } from "@/lib/settings";
import { referralLink } from "@/lib/telegram";

export const GET = withUser(async (_req, user) => {
  await requireFeature("features.referrals");
  const size = await getSetting<number>("referral.leaderboardSize");
  const [history, totals, top, [inviterReward, inviteeReward]] = await Promise.all([
    db.referral.findMany({ where: { inviterId: user.id }, orderBy: { createdAt: "desc" }, take: 50, include: { invitee: { select: { firstName: true, username: true } } } }),
    db.referral.aggregate({ where: { inviterId: user.id }, _count: true, _sum: { rewardPoints: true } }),
    db.referral.groupBy({ by: ["inviterId"], _count: { _all: true }, orderBy: { _count: { inviterId: "desc" } }, take: size }),
    Promise.all([getSetting<number>("referral.inviterReward"), getSetting<number>("referral.inviteeReward")]),
  ]);
  const names = await db.user.findMany({ where: { id: { in: top.map((t) => t.inviterId) } }, select: { id: true, firstName: true } });
  const nameOf = new Map(names.map((n) => [n.id, n.firstName]));
  return json({
    code: user.referralCode,
    link: referralLink(user.referralCode),
    invited: totals._count,
    earned: totals._sum.rewardPoints ?? 0,
    rewards: { inviter: inviterReward, invitee: inviteeReward },
    history: history.map((h) => ({ id: h.id, name: h.invitee.firstName, username: h.invitee.username, reward: h.rewardPoints, at: h.createdAt })),
    leaderboard: top.map((t, i) => ({ rank: i + 1, name: nameOf.get(t.inviterId) ?? "Player", count: t._count._all, isYou: t.inviterId === user.id })),
  });
});
