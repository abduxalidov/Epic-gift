import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { roundDto, settleIfCrashed } from "@/lib/rocket";
import { allSettings } from "@/lib/settings";

/** Polled by the client during a flight to learn when the rocket crashes. */
export const GET = withUser(async (_req, user) => {
  const s = await allSettings();
  let round = await db.rocketRound.findFirst({ where: { userId: user.id }, orderBy: { startedAt: "desc" } });
  if (round) round = await settleIfCrashed(round);
  return json({
    enabled: s.get("features.rocket") as boolean,
    limits: { min: s.get("rocket.minBet") as number, max: s.get("rocket.maxBet") as number },
    round: round ? roundDto(round) : null,
    serverNow: Date.now(),
  });
}, 600);
