import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";

export const GET = withUser(async (_req, user) => {
  const rows = await db.rocketRound.findMany({ where: { userId: user.id, status: { not: "FLYING" } }, orderBy: { startedAt: "desc" }, take: 20 });
  return json({ rounds: rows.map((r) => ({ id: r.id, bet: r.bet, status: r.status, crashPoint: r.crashPoint, cashoutAt: r.cashoutAt, payout: r.payout, at: r.startedAt })) });
});
