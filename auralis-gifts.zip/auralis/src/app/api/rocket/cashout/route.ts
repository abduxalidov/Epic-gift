import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyDelta } from "@/lib/economy";
import { multiplierAt } from "@/lib/rocket";

const body = z.object({ roundId: z.string().min(1).max(40) });

export const POST = withUser(async (req, user) => {
  const { roundId } = body.parse(await readJson(req));
  const out = await db.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${user.id}))`;
    const round = await tx.rocketRound.findFirst({ where: { id: roundId, userId: user.id, status: "FLYING" } });
    if (!round) throw new ApiError(404, "There's no rocket in flight.", "no_round");
    const now = multiplierAt(round.growthRate, Date.now() - round.startedAt.getTime());
    if (now >= round.crashPoint) {
      await tx.rocketRound.update({ where: { id: round.id }, data: { status: "CRASHED", endedAt: new Date() } });
      return { status: "CRASHED" as const, crashPoint: round.crashPoint };
    }
    const multiplier = Math.floor(now * 100) / 100;
    const payout = Math.floor(round.bet * multiplier);
    await tx.rocketRound.update({ where: { id: round.id }, data: { status: "CASHED_OUT", cashoutAt: multiplier, payout, endedAt: new Date() } });
    const balance = await applyDelta(tx, user.id, payout, "ROCKET_WIN", { roundId: round.id, multiplier });
    return { status: "CASHED_OUT" as const, multiplier, payout, balance, crashPoint: round.crashPoint };
  });
  return json(out);
}, 60);
