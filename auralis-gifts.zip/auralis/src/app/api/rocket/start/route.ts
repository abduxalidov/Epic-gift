import { z } from "zod";
import { ApiError, json, readJson } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyDelta } from "@/lib/economy";
import { drawCrashPoint, roundDto, settleIfCrashed } from "@/lib/rocket";
import { allSettings, requireFeature } from "@/lib/settings";

const body = z.object({ bet: z.number().int().positive() });

export const POST = withUser(async (req, user) => {
  const { bet } = body.parse(await readJson(req));
  await requireFeature("features.rocket");
  const s = await allSettings();
  const min = s.get("rocket.minBet") as number, max = s.get("rocket.maxBet") as number;
  if (bet < min || bet > max) throw new ApiError(400, `Bets run from ${min} to ${max} demo points.`, "bet_range");

  const out = await db.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${user.id}))`; // one round per player at a time
    const open = await tx.rocketRound.findFirst({ where: { userId: user.id, status: "FLYING" } });
    if (open) {
      const settled = await settleIfCrashed(open);
      if (settled.status === "FLYING") throw new ApiError(409, "You already have a rocket in flight.", "round_open");
    }
    const round = await tx.rocketRound.create({
      data: {
        userId: user.id, bet,
        crashPoint: drawCrashPoint(s.get("rocket.houseEdgePct") as number, s.get("rocket.maxMultiplier") as number),
        growthRate: s.get("rocket.growthRate") as number,
      },
    });
    const balance = await applyDelta(tx, user.id, -bet, "ROCKET_BET", { roundId: round.id });
    return { round, balance };
  });
  return json({ round: roundDto(out.round), balance: out.balance, serverNow: Date.now() });
}, 40);
