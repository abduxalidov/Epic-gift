import { json } from "@/lib/api-server";
import { withUser } from "@/lib/auth";
import { publicUser } from "@/lib/users";

export const GET = withUser(async (_req, user) => json({ user: publicUser(user) }));
