"use client";
import { useState } from "react";
import { Ticket } from "lucide-react";
import { useApp } from "@/components/AppProvider";
import { Avatar, EmptyState, ErrorState, Glass, PointsPill, Skeleton } from "@/components/ui/bits";
import { Button } from "@/components/ui/Button";
import { TX_LABEL, api, errMsg, fmt, fmtDate, timeAgo } from "@/lib/client";
import type { PublicUser } from "@/lib/types";
import { useApi } from "@/lib/useApi";

type Data = {
  user: PublicUser;
  stats: { totalGifts: number; totalCollected: number; invited: number; referralEarnings: number };
  transactions: { id: string; type: string; amount: number; balanceAfter: number; at: string }[];
};

export default function Profile() {
  const { user, setBalance, toast, haptic } = useApp();
  const { data, error, loading, retry, reload } = useApi<Data>("/profile");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function redeem(e: React.FormEvent) {
    e.preventDefault();
    if (!code.trim()) return;
    setBusy(true);
    try {
      const r = await api<{ points: number; balance: number }>("/promo/redeem", { body: { code: code.trim() } });
      setBalance(r.balance); setCode(""); haptic("success");
      toast(`Code accepted: +${fmt(r.points)} demo points`);
      reload();
    } catch (err) {
      haptic("error"); toast(errMsg(err), "err");
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-5">
      <Glass className="flex flex-col items-center p-6 text-center">
        <Avatar name={user.firstName} src={user.photoUrl} size={84} />
        <h1 className="mt-3 font-display text-xl font-medium">{user.firstName} {user.lastName ?? ""}</h1>
        <p className="text-sm text-white/50">{user.username ? `@${user.username}` : "No username"} · ID {user.telegramId}</p>
        <p className="mt-0.5 text-xs text-white/35">Joined {fmtDate(user.createdAt)}</p>
        <div className="mt-4"><PointsPill value={user.balance} /></div>
        <p className="mt-2 text-xs text-white/35">Demo points: no cash value, can't be withdrawn.</p>
      </Glass>

      {loading && !data ? <Skeleton className="h-24" /> : error && !data ? <ErrorState message={error} onRetry={retry} /> : data && (
        <div className="grid grid-cols-2 gap-3">
          {[["Gifts owned", data.stats.totalGifts], ["Ever collected", data.stats.totalCollected], ["Friends invited", data.stats.invited], ["Referral points", fmt(data.stats.referralEarnings)]].map(([l, v]) => (
            <Glass key={l as string} className="p-4"><p className="font-display text-xl">{v}</p><p className="text-xs text-white/45">{l}</p></Glass>
          ))}
        </div>
      )}

      <form onSubmit={redeem}>
        <Glass className="p-4">
          <label htmlFor="promo" className="flex items-center gap-2 text-sm font-semibold"><Ticket className="h-4 w-4 text-aura-pink" /> Promo code</label>
          <div className="mt-2.5 flex gap-2">
            <input id="promo" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} maxLength={32} autoCapitalize="characters" autoComplete="off" placeholder="Enter code" className="field uppercase tracking-wider" />
            <Button type="submit" loading={busy} disabled={!code.trim()}>Redeem</Button>
          </div>
        </Glass>
      </form>

      <section>
        <h2 className="mb-3 font-display text-base font-medium">Transactions</h2>
        {loading && !data ? <Skeleton className="h-48" /> : !data?.transactions.length ? <EmptyState emoji="🧾" title="No activity yet" text="Rewards, boxes and exchanges will be listed here." /> : (
          <Glass className="divide-y divide-white/5">
            {data.transactions.map((t) => (
              <div key={t.id} className="flex items-center justify-between p-3.5">
                <div><p className="text-sm font-semibold">{TX_LABEL[t.type] ?? t.type}</p><p className="text-xs text-white/40">{timeAgo(t.at)}</p></div>
                <div className="text-right"><p className={t.amount > 0 ? "text-sm font-bold text-emerald-400" : t.amount < 0 ? "text-sm font-bold text-rose-400" : "text-sm font-bold text-white/50"}>{t.amount > 0 ? "+" : ""}{fmt(t.amount)}</p><p className="text-xs text-white/35">{fmt(t.balanceAfter)}</p></div>
              </div>
            ))}
          </Glass>
        )}
      </section>
    </div>
  );
}
