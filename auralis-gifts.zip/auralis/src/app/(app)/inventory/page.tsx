"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import clsx from "clsx";
import { EmptyState, ErrorState, Glass, Skeleton } from "@/components/ui/bits";
import { Button } from "@/components/ui/Button";
import { GiftArt } from "@/components/gifts/GiftArt";
import { GiftCard } from "@/components/gifts/GiftCard";
import { GiftSheet } from "@/components/gifts/GiftSheet";
import { RARITY, RARITY_ORDER, type RarityKey } from "@/lib/rarity";
import { fmtDate } from "@/lib/client";
import type { GiftDto, InvItem } from "@/lib/types";
import { useApi } from "@/lib/useApi";

type Tab = "mine" | "collection" | "history";
type Sort = "rarity" | "newest" | "value" | "name";
const SOURCE: Record<string, string> = { FREE_BOX: "Free box", PAID_BOX: "Box", DAILY: "Daily reward", PROMO: "Promo", ADMIN: "Support" };

export default function InventoryPage() {
  const [tab, setTab] = useState<Tab>("mine");
  return (
    <div className="space-y-5">
      <h1 className="font-display text-xl font-medium">My gifts</h1>
      <div role="tablist" className="glass grid grid-cols-3 rounded-2xl p-1">
        {([["mine", "Inventory"], ["collection", "Collection"], ["history", "History"]] as const).map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={clsx("rounded-xl py-2 text-sm font-semibold transition", tab === k ? "btn-primary text-white" : "text-white/50")}>{label}</button>
        ))}
      </div>
      {tab === "mine" && <Mine />}
      {tab === "collection" && <Collection />}
      {tab === "history" && <History />}
    </div>
  );
}

function Mine() {
  const { data, error, loading, retry, reload } = useApi<{ items: InvItem[] }>("/inventory");
  const [rarity, setRarity] = useState<RarityKey | "ALL">("ALL");
  const [sort, setSort] = useState<Sort>("rarity");
  const [open, setOpen] = useState<{ gift: GiftDto; ids: string[]; at: string } | null>(null);

  const groups = useMemo(() => {
    const m = new Map<string, { gift: GiftDto; ids: string[]; at: string }>();
    for (const i of data?.items ?? []) {
      const g = m.get(i.giftId);
      if (g) g.ids.push(i.id);
      else m.set(i.giftId, { gift: i.gift, ids: [i.id], at: i.acquiredAt });
    }
    const list = [...m.values()].filter((g) => rarity === "ALL" || g.gift.rarity === rarity);
    const by: Record<Sort, (a: (typeof list)[number], b: (typeof list)[number]) => number> = {
      rarity: (a, b) => RARITY[b.gift.rarity].rank - RARITY[a.gift.rarity].rank || b.gift.exchangeValue - a.gift.exchangeValue,
      newest: (a, b) => +new Date(b.at) - +new Date(a.at),
      value: (a, b) => b.gift.exchangeValue - a.gift.exchangeValue,
      name: (a, b) => a.gift.name.localeCompare(b.gift.name),
    };
    return list.sort(by[sort]);
  }, [data, rarity, sort]);

  if (loading && !data) return <Grid><SkeletonCards /></Grid>;
  if (error && !data) return <ErrorState message={error} onRetry={retry} />;
  if (!data?.items.length) return <EmptyState emoji="🎁" title="No gifts yet" text="Open your free box to start your collection." action={<Link href="/"><Button size="sm">Open a box</Button></Link>} />;

  return (
    <>
      <div className="flex items-center gap-2">
        <div className="no-scrollbar -mr-1 flex flex-1 gap-1.5 overflow-x-auto">
          {(["ALL", ...RARITY_ORDER] as const).map((r) => (
            <button key={r} onClick={() => setRarity(r)} aria-pressed={rarity === r}
              className={clsx("shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition", rarity === r ? "border-white/30 bg-white/15" : "border-white/10 text-white/50")}
              style={rarity === r && r !== "ALL" ? { color: RARITY[r].color } : undefined}>{r === "ALL" ? "All" : RARITY[r].label}</button>
          ))}
        </div>
        <select aria-label="Sort gifts" value={sort} onChange={(e) => setSort(e.target.value as Sort)} className="field w-auto shrink-0 py-1.5 text-xs">
          <option value="rarity">Rarity</option><option value="newest">Newest</option><option value="value">Value</option><option value="name">Name</option>
        </select>
      </div>
      {groups.length === 0 ? (
        <EmptyState emoji="🔍" title="Nothing here" text="You have no gifts of this rarity yet." action={<Button size="sm" variant="ghost" onClick={() => setRarity("ALL")}>Show all</Button>} />
      ) : (
        <Grid>{groups.map((g) => <GiftCard key={g.gift.id} gift={g.gift} count={g.ids.length} onClick={() => setOpen(g)} />)}</Grid>
      )}
      <GiftSheet gift={open?.gift ?? null} itemIds={open?.ids} acquiredAt={open?.at} onClose={() => setOpen(null)} onExchanged={reload} />
    </>
  );
}

function Collection() {
  const { data, error, loading, retry } = useApi<{ gifts: (GiftDto & { collected: boolean; owned: number })[] }>("/gifts");
  const [open, setOpen] = useState<GiftDto | null>(null);
  if (loading && !data) return <Grid><SkeletonCards /></Grid>;
  if (error && !data) return <ErrorState message={error} onRetry={retry} />;
  if (!data?.gifts.length) return <EmptyState emoji="📦" title="The catalog is empty" text="Gifts will show up here once they're added." />;
  const got = data.gifts.filter((g) => g.collected).length;
  return (
    <>
      <Glass className="p-4">
        <div className="flex items-end justify-between"><span className="text-sm text-white/60">Collected</span><span className="font-display text-lg">{got}<span className="text-white/40">/{data.gifts.length}</span></span></div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full btn-primary transition-all" style={{ width: `${(got / data.gifts.length) * 100}%` }} /></div>
      </Glass>
      <Grid>{data.gifts.map((g) => <GiftCard key={g.id} gift={g} dim={!g.collected} count={g.owned} onClick={() => setOpen(g)} />)}</Grid>
      <GiftSheet gift={open} onClose={() => setOpen(null)} />
    </>
  );
}

function History() {
  const { data, error, loading, retry } = useApi<{ history: { id: string; source: string; acquiredAt: string; exchangedAt: string | null; gift: GiftDto }[] }>("/inventory/history");
  if (loading && !data) return <Skeleton className="h-64 w-full" />;
  if (error && !data) return <ErrorState message={error} onRetry={retry} />;
  if (!data?.history.length) return <EmptyState emoji="🕑" title="No history yet" text="Gifts you collect or exchange will be listed here." />;
  return (
    <Glass className="divide-y divide-white/5">
      {data.history.map((h) => (
        <div key={h.id} className="flex items-center gap-3 p-3">
          <GiftArt gift={h.gift} size={44} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{h.gift.name}</p>
            <p className="text-xs text-white/45">{SOURCE[h.source] ?? h.source} · {fmtDate(h.acquiredAt)}</p>
          </div>
          {h.exchangedAt && <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] text-white/60">Exchanged</span>}
        </div>
      ))}
    </Glass>
  );
}

const Grid = ({ children }: { children: React.ReactNode }) => <div className="grid grid-cols-2 gap-3">{children}</div>;
const SkeletonCards = () => <>{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-40 rounded-3xl" />)}</>;
