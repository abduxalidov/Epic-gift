"use client";
import { useState } from "react";
import clsx from "clsx";
import { Copy, Send, Trophy } from "lucide-react";
import { useApp } from "@/components/AppProvider";
import { Avatar, EmptyState, ErrorState, Glass, Skeleton } from "@/components/ui/bits";
import { Button } from "@/components/ui/Button";
import { fmt, timeAgo } from "@/lib/client";
import { useApi } from "@/lib/useApi";

type Data = {
  code: string; link: string; invited: number; earned: number; rewards: { inviter: number; invitee: number };
  history: { id: string; name: string; username: string | null; reward: number; at: string }[];
  leaderboard: { rank: number; name: string; count: number; isYou: boolean }[];
};

export default function Referrals() {
  const { tg, toast, haptic } = useApp();
  const { data, error, loading, retry } = useApi<Data>("/referrals");
  const [tab, setTab] = useState<"friends" | "top">("friends");

  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); haptic("light"); toast("Link copied"); } catch { toast("Couldn't copy. Select the link and copy it manually.", "err"); }
  }
  function share(link: string) {
    const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent("Come collect gifts with me!")}`;
    if (tg?.openTelegramLink) tg.openTelegramLink(url); else window.open(url, "_blank");
  }

  if (loading && !data) return <div className="space-y-4"><Skeleton className="h-8 w-40" /><Skeleton className="h-52" /><Skeleton className="h-40" /></div>;
  if (error && !data) return <div className="space-y-4"><h1 className="font-display text-xl font-medium">Friends</h1><ErrorState message={error} onRetry={retry} /></div>;
  if (!data) return null;

  return (
    <div className="space-y-5">
      <h1 className="font-display text-xl font-medium">Friends</h1>
      <Glass className="p-5">
        <p className="text-sm text-white/60">You earn <b className="text-amber-300">◆ {fmt(data.rewards.inviter)}</b> for every friend who joins. They start with <b className="text-amber-300">◆ {fmt(data.rewards.invitee)}</b> extra.</p>
        <div className="mt-4 rounded-2xl bg-black/30 p-3.5">
          <p className="text-xs text-white/45">Your code</p>
          <p className="mt-0.5 font-display text-2xl tracking-widest">{data.code}</p>
          <p className="mt-2 break-all text-xs text-white/45">{data.link}</p>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Button onClick={() => share(data.link)}><Send className="h-4 w-4" /> Share</Button>
          <Button variant="ghost" onClick={() => copy(data.link)}><Copy className="h-4 w-4" /> Copy link</Button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2.5 text-center">
          <div className="rounded-2xl bg-white/5 py-3"><p className="font-display text-xl">{data.invited}</p><p className="text-xs text-white/45">Friends invited</p></div>
          <div className="rounded-2xl bg-white/5 py-3"><p className="font-display text-xl">{fmt(data.earned)}</p><p className="text-xs text-white/45">Points earned</p></div>
        </div>
      </Glass>

      <div role="tablist" className="glass grid grid-cols-2 rounded-2xl p-1">
        {([["friends", "My invites"], ["top", "Leaderboard"]] as const).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={clsx("rounded-xl py-2 text-sm font-semibold", tab === k ? "btn-primary text-white" : "text-white/50")}>{l}</button>
        ))}
      </div>

      {tab === "friends" ? (
        data.history.length === 0 ? <EmptyState emoji="🤝" title="No friends yet" text="Share your link. Friends who join through it show up here." /> : (
          <Glass className="divide-y divide-white/5">
            {data.history.map((h) => (
              <div key={h.id} className="flex items-center gap-3 p-3">
                <Avatar name={h.name} size={38} />
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{h.name}</p><p className="text-xs text-white/45">{h.username ? `@${h.username} · ` : ""}{timeAgo(h.at)}</p></div>
                <span className="text-sm font-bold text-emerald-400">+{fmt(h.reward)}</span>
              </div>
            ))}
          </Glass>
        )
      ) : data.leaderboard.length === 0 ? <EmptyState emoji="🏆" title="Nobody's on the board yet" text="Invite the first friend and take the top spot." /> : (
        <Glass className="divide-y divide-white/5">
          {data.leaderboard.map((l) => (
            <div key={l.rank} className={clsx("flex items-center gap-3 p-3", l.isYou && "bg-aura-violet/15")}>
              <span className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-sm font-bold">{l.rank <= 3 ? <Trophy className="h-4 w-4 text-amber-300" /> : l.rank}</span>
              <p className="min-w-0 flex-1 truncate text-sm font-semibold">{l.name}{l.isYou && <span className="ml-2 text-xs font-normal text-aura-cyan">You</span>}</p>
              <span className="text-sm font-bold">{l.count}</span>
            </div>
          ))}
        </Glass>
      )}
    </div>
  );
}
