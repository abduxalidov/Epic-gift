"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Rocket as RocketIcon, ShieldCheck } from "lucide-react";
import clsx from "clsx";
import { useApp } from "@/components/AppProvider";
import { EmptyState, ErrorState, Glass, PointsPill, Skeleton } from "@/components/ui/bits";
import { Button } from "@/components/ui/Button";
import { api, errMsg, fmt } from "@/lib/client";
import { useApi } from "@/lib/useApi";

type RoundDto = { id: string; status: "FLYING" | "CASHED_OUT" | "CRASHED"; bet: number; growthRate: number; startedAt: number; crashPoint: number | null; cashoutAt: number | null; payout: number };
type StateRes = { enabled: boolean; limits: { min: number; max: number }; round: RoundDto | null; serverNow: number };
type Phase = "idle" | "flying" | "crashed" | "cashed";
type Result = { crash: number; mult?: number; payout?: number };

const W = 340, H = 250, PAD = 22;
const STARS = [...Array(26)].map((_, i) => ({ x: (i * 97) % W, y: (i * 53 + 11) % (H - 20), r: 0.6 + ((i * 7) % 5) / 5, d: (i % 6) * 0.5 }));

export default function RocketPage() {
  const { user, setBalance, toast, haptic, refresh } = useApp();
  const [boot, setBoot] = useState<{ enabled: boolean; limits: { min: number; max: number } } | null>(null);
  const [bootErr, setBootErr] = useState<string | null>(null);
  const [round, setRound] = useState<RoundDto | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [t, setT] = useState(0);
  const [bet, setBet] = useState(50);
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const offset = useRef(0);
  const history = useApi<{ rounds: { id: string; status: string; crashPoint: number; cashoutAt: number | null; payout: number; bet: number }[] }>("/rocket/history");

  const load = useCallback(async () => {
    try {
      setBootErr(null);
      const s = await api<StateRes>("/rocket/state");
      setBoot({ enabled: s.enabled, limits: s.limits });
      setBet((b) => Math.min(Math.max(b, s.limits.min), s.limits.max));
      if (s.round?.status === "FLYING") { // resume a flight that was already running
        offset.current = s.serverNow - Date.now();
        setRound(s.round); setPhase("flying");
      }
    } catch (e) { setBootErr(errMsg(e)); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const finish = useCallback((r: RoundDto) => {
    const crash = r.crashPoint ?? 1;
    if (r.status === "CRASHED") {
      setT((Math.log(Math.max(crash, 1)) / r.growthRate) * 1000);
      setResult({ crash }); setPhase("crashed"); haptic("error");
    } else {
      setT(((Math.log(r.cashoutAt ?? 1)) / r.growthRate) * 1000);
      setResult({ crash, mult: r.cashoutAt ?? 1, payout: r.payout }); setPhase("cashed");
    }
    refresh(); history.reload();
  }, [haptic, refresh, history]);

  // animate locally from server time; poll to learn the (hidden) crash moment
  useEffect(() => {
    if (phase !== "flying" || !round) return;
    let raf = 0;
    const loop = () => { setT(Date.now() + offset.current - round.startedAt); raf = requestAnimationFrame(loop); };
    raf = requestAnimationFrame(loop);
    const poll = setInterval(async () => {
      try {
        const s = await api<StateRes>("/rocket/state");
        if (s.round?.id === round.id && s.round.status !== "FLYING") finish(s.round);
      } catch {}
    }, 280);
    return () => { cancelAnimationFrame(raf); clearInterval(poll); };
  }, [phase, round, finish]);

  async function launch() {
    setBusy(true);
    try {
      const r = await api<{ round: RoundDto; balance: number; serverNow: number }>("/rocket/start", { body: { bet } });
      offset.current = r.serverNow - Date.now();
      setBalance(r.balance); setRound(r.round); setResult(null); setT(0); setPhase("flying"); haptic("light");
    } catch (e) { haptic("error"); toast(errMsg(e), "err"); } finally { setBusy(false); }
  }

  async function cashOut() {
    if (!round) return;
    setBusy(true);
    try {
      const r = await api<{ status: "CASHED_OUT" | "CRASHED"; multiplier?: number; payout?: number; balance?: number; crashPoint: number }>("/rocket/cashout", { body: { roundId: round.id } });
      if (r.status === "CASHED_OUT") {
        setBalance(r.balance!); setT((Math.log(r.multiplier!) / round.growthRate) * 1000);
        setResult({ crash: r.crashPoint, mult: r.multiplier, payout: r.payout }); setPhase("cashed"); haptic("success");
      } else {
        setT((Math.log(Math.max(r.crashPoint, 1)) / round.growthRate) * 1000);
        setResult({ crash: r.crashPoint }); setPhase("crashed"); haptic("error");
      }
      history.reload();
    } catch (e) { toast(errMsg(e), "err"); } finally { setBusy(false); }
  }

  const rate = round?.growthRate ?? 0.15;
  const mult = phase === "crashed" ? result?.crash ?? 1 : phase === "cashed" ? result?.mult ?? 1 : Math.exp((rate * Math.max(t, 0)) / 1000);

  const geo = useMemo(() => {
    const tt = Math.max(t, 0), span = Math.max(tt, 7000);
    const yMax = Math.max(2, Math.exp((rate * tt) / 1000) * 1.15);
    const pts: [number, number][] = [];
    for (let i = 0; i <= 40; i++) {
      const s = (tt * i) / 40;
      pts.push([PAD + (s / span) * (W - 2 * PAD - 24), H - PAD - (Math.log(Math.exp((rate * s) / 1000)) / Math.log(yMax)) * (H - 2 * PAD - 14)]);
    }
    const [x, y] = pts[pts.length - 1], [px, py] = pts[pts.length - 3];
    const moved = Math.hypot(x - px, y - py) > 0.5;
    const rot = moved ? (Math.atan2(y - py, x - px) * 180) / Math.PI + 90 : 35;
    const line = pts.map(([a, b], i) => `${i ? "L" : "M"}${a.toFixed(1)},${b.toFixed(1)}`).join(" ");
    return { x, y, rot, line, area: `${line} L${x.toFixed(1)},${H - PAD} L${PAD},${H - PAD}Z` };
  }, [t, rate]);

  if (bootErr && !boot) return <div className="space-y-4"><h1 className="font-display text-xl font-medium">Rocket</h1><ErrorState message={bootErr} onRetry={load} /></div>;
  if (!boot) return <div className="space-y-4"><Skeleton className="h-8 w-32" /><Skeleton className="h-72" /><Skeleton className="h-36" /></div>;
  if (!boot.enabled) return <div className="space-y-4"><h1 className="font-display text-xl font-medium">Rocket</h1><EmptyState emoji="🚀" title="Rocket is paused" text="The demo is switched off for now. Check back soon." /></div>;

  const { min, max } = boot.limits;
  const flying = phase === "flying";
  const betOk = bet >= min && bet <= max && bet <= user.balance;
  const clampBet = (n: number) => setBet(Math.round(Math.min(Math.max(n, min), max)));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl font-medium">Rocket</h1>
        <PointsPill value={user.balance} />
      </div>
      <div className="flex items-center gap-2 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 px-3 py-2 text-xs text-emerald-200">
        <ShieldCheck className="h-4 w-4 shrink-0" /> Demo mode: virtual points only. No deposits, no withdrawals, no cash value.
      </div>

      {history.data && history.data.rounds.length > 0 && (
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto" aria-label="Recent rounds">
          {history.data.rounds.slice(0, 14).map((r) => (
            <span key={r.id} className={clsx("shrink-0 rounded-full px-2.5 py-1 text-xs font-bold", r.status === "CASHED_OUT" ? "bg-emerald-400/15 text-emerald-300" : "bg-rose-400/15 text-rose-300")}>
              {r.status === "CASHED_OUT" ? `${r.cashoutAt?.toFixed(2)}x` : `${r.crashPoint.toFixed(2)}x`}
            </span>
          ))}
        </div>
      )}

      {/* flight deck */}
      <div className="glass relative overflow-hidden rounded-[2rem]" style={{ background: "linear-gradient(180deg,#120d33 0%,#0a0820 70%,#07060f)" }}>
        <svg viewBox={`0 0 ${W} ${H}`} className="block w-full" role="img" aria-label={`Rocket at ${mult.toFixed(2)} times`}>
          <defs>
            <linearGradient id="rk-line" x1="0" x2="1"><stop offset="0" stopColor="#22d3ee" /><stop offset=".55" stopColor="#8b5cf6" /><stop offset="1" stopColor="#e879f9" /></linearGradient>
            <linearGradient id="rk-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#8b5cf6" stopOpacity=".35" /><stop offset="1" stopColor="#8b5cf6" stopOpacity="0" /></linearGradient>
            <linearGradient id="rk-body" x1="0" x2="1"><stop offset="0" stopColor="#e2e8f0" /><stop offset="1" stopColor="#94a3b8" /></linearGradient>
          </defs>
          {STARS.map((s, i) => <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff" opacity={0.5} className="animate-glow" style={{ animationDelay: `${s.d}s` }} />)}
          {[0.25, 0.5, 0.75].map((f) => <line key={f} x1={PAD} x2={W - PAD} y1={H - PAD - f * (H - 2 * PAD)} y2={H - PAD - f * (H - 2 * PAD)} stroke="#fff" strokeOpacity=".05" />)}
          <line x1={PAD} x2={W - PAD} y1={H - PAD} y2={H - PAD} stroke="#fff" strokeOpacity=".15" />
          <path d={geo.area} fill="url(#rk-area)" />
          <path d={geo.line} fill="none" stroke="url(#rk-line)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />

          {phase !== "crashed" ? (
            <g transform={`translate(${geo.x} ${geo.y}) rotate(${geo.rot})`}>
              {flying && <motion.path d="M-5 14 Q0 40 5 14Z" fill="#fbbf24" animate={{ scaleY: [1, 1.5, 0.9, 1.4, 1], opacity: [0.9, 1, 0.8, 1, 0.9] }} transition={{ duration: 0.28, repeat: Infinity }} style={{ transformOrigin: "0px 14px" }} />}
              {flying && <motion.path d="M-3 14 Q0 28 3 14Z" fill="#fff" animate={{ scaleY: [1, 1.3, 1] }} transition={{ duration: 0.2, repeat: Infinity }} style={{ transformOrigin: "0px 14px" }} />}
              <path d="M-9 4 L-16 18 L-6 14Z M9 4 L16 18 L6 14Z" fill="#e879f9" />
              <path d="M0 -24 C10 -12 10 6 8 16 L-8 16 C-10 6 -10 -12 0 -24Z" fill="url(#rk-body)" />
              <path d="M0 -24 C5 -18 7 -12 8 -8 L-8 -8 C-7 -12 -5 -18 0 -24Z" fill="#8b5cf6" />
              <circle cx="0" cy="-1" r="4.2" fill="#0c0a1a" stroke="#22d3ee" strokeWidth="1.6" />
            </g>
          ) : (
            <g transform={`translate(${geo.x} ${geo.y})`}>
              {[0, 1, 2].map((i) => <motion.circle key={i} r="6" fill="none" stroke={i ? "#fb7185" : "#fbbf24"} strokeWidth="3" initial={{ r: 4, opacity: 1 }} animate={{ r: 34 + i * 12, opacity: 0 }} transition={{ duration: 0.8, delay: i * 0.08 }} />)}
              {[...Array(10)].map((_, i) => <motion.circle key={i} r="2.4" fill={i % 2 ? "#fbbf24" : "#fb7185"} initial={{ cx: 0, cy: 0, opacity: 1 }} animate={{ cx: Math.cos((i / 10) * 6.283) * 44, cy: Math.sin((i / 10) * 6.283) * 44, opacity: 0 }} transition={{ duration: 0.9 }} />)}
            </g>
          )}
        </svg>

        <div className="pointer-events-none absolute inset-x-0 top-5 text-center" aria-live="polite">
          <div className={clsx("font-display text-5xl font-bold tabular-nums drop-shadow-[0_4px_24px_rgba(139,92,246,.6)]", phase === "crashed" && "text-rose-400", phase === "cashed" && "text-emerald-300")}>
            {mult.toFixed(2)}<span className="text-3xl">x</span>
          </div>
          <AnimatePresence mode="wait">
            <motion.p key={phase} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-1 text-sm text-white/60">
              {phase === "idle" && "Set a bet and launch"}
              {flying && "Cash out before it crashes"}
              {phase === "crashed" && "Crashed. The bet is gone"}
              {phase === "cashed" && `Cashed out +${fmt(result?.payout ?? 0)} points (it crashed at ${result?.crash.toFixed(2)}x)`}
            </motion.p>
          </AnimatePresence>
        </div>
      </div>

      {/* controls */}
      <Glass className="space-y-3 p-4">
        {flying ? (
          <Button size="lg" variant="gold" className="w-full" loading={busy} onClick={cashOut}>
            Cash out <span>◆ {fmt(Math.floor((round?.bet ?? 0) * Math.floor(mult * 100) / 100))}</span>
          </Button>
        ) : (
          <>
            <div>
              <label htmlFor="bet" className="text-xs text-white/50">Bet (demo points, {fmt(min)}–{fmt(max)})</label>
              <div className="mt-1.5 flex gap-2">
                <input id="bet" inputMode="numeric" value={bet} onChange={(e) => setBet(Number(e.target.value.replace(/\D/g, "")) || 0)} onBlur={() => clampBet(bet)} className="field text-lg font-bold" />
              </div>
              <div className="mt-2 grid grid-cols-4 gap-2">
                <Button variant="ghost" size="sm" onClick={() => clampBet(min)}>Min</Button>
                <Button variant="ghost" size="sm" onClick={() => clampBet(bet / 2)}>½</Button>
                <Button variant="ghost" size="sm" onClick={() => clampBet(bet * 2)}>×2</Button>
                <Button variant="ghost" size="sm" onClick={() => clampBet(Math.min(max, user.balance))}>Max</Button>
              </div>
            </div>
            <Button size="lg" className="w-full" loading={busy} disabled={!betOk} onClick={launch}>
              <RocketIcon className="h-5 w-5" /> {phase === "idle" ? "Launch" : "Fly again"} for ◆ {fmt(bet)}
            </Button>
            {!betOk && bet > user.balance && <p className="text-center text-xs text-amber-300">You don't have enough demo points. Claim a daily reward or open a free box.</p>}
          </>
        )}
      </Glass>
    </div>
  );
}
