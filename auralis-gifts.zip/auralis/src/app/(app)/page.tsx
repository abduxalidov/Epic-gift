"use client";
import { useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronRight, Gift, Lock, Sparkles, Users } from "lucide-react";
import clsx from "clsx";
import { useApp } from "@/components/AppProvider";
import { Avatar, ErrorState, Glass, PointsPill, Skeleton } from "@/components/ui/bits";
import { Button } from "@/components/ui/Button";
import { Sheet } from "@/components/ui/Sheet";
import { GiftArt } from "@/components/gifts/GiftArt";
import { GiftBoxArt } from "@/components/gifts/GiftBoxArt";
import { GiftCard } from "@/components/gifts/GiftCard";
import { GiftSheet } from "@/components/gifts/GiftSheet";
import { RarityBadge } from "@/components/ui/bits";
import { api, countdown, errMsg, fmt, timeAgo } from "@/lib/client";
import type { Bootstrap, GiftDto } from "@/lib/types";
import { useApi } from "@/lib/useApi";
import { useNow } from "@/lib/useNow";

export default function Home() {
  const { user, setBalance, toast, haptic } = useApp();
  const { data, error, loading, reload, retry } = useApi<Bootstrap>("/bootstrap");
  useNow(1000); // keeps countdowns ticking
  const [shaking, setShaking] = useState(false);
  const [reveal, setReveal] = useState<GiftDto | null>(null);
  const [detail, setDetail] = useState<GiftDto | null>(null);
  const [claiming, setClaiming] = useState(false);

  async function openBox(kind: "free" | "paid") {
    setShaking(true);
    try {
      const [r] = await Promise.all([
        api<{ gift: GiftDto; balance: number }>("/boxes/open", { body: { kind } }),
        new Promise((res) => setTimeout(res, 1300)), // let the shake play
      ]);
      setBalance(r.balance);
      haptic("success");
      setReveal(r.gift);
      reload();
    } catch (e) {
      haptic("error");
      toast(errMsg(e), "err");
      reload();
    } finally {
      setShaking(false);
    }
  }

  async function claimDaily() {
    setClaiming(true);
    try {
      const r = await api<{ points: number; gift: GiftDto | null; balance: number }>("/daily/claim", { method: "POST", body: {} });
      setBalance(r.balance);
      haptic("success");
      toast(`+${fmt(r.points)} demo points${r.gift ? ` and ${r.gift.name}` : ""}`);
      if (r.gift) setReveal(r.gift);
      reload();
    } catch (e) {
      haptic("error");
      toast(errMsg(e), "err");
      reload();
    } finally {
      setClaiming(false);
    }
  }

  if (loading && !data) return <HomeSkeleton />;
  if (error && !data) return <ErrorState message={error} onRetry={retry} />;
  if (!data) return null;
  const { config: c, daily, freeBox } = data;
  const freeReady = freeBox.available;
  const doneUpTo = daily.canClaim ? daily.nextIdx : (daily.claimedIdx ?? -1) + 1;

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar name={user.firstName} src={user.photoUrl} />
          <div>
            <p className="text-xs text-white/50">Welcome back</p>
            <p className="font-display text-sm font-medium">{user.firstName}</p>
          </div>
        </div>
        <PointsPill value={user.balance} />
      </header>

      {/* Box hero */}
      <Glass className="relative overflow-hidden p-5 text-center">
        <div className="pointer-events-none absolute -top-16 left-1/2 h-56 w-56 -translate-x-1/2 rounded-full bg-aura-violet/40 blur-3xl" />
        <div className="relative flex justify-center"><GiftBoxArt size={168} shaking={shaking} /></div>
        <h1 className="relative mt-1 font-display text-xl font-medium">{freeReady && c.features.freeBox ? "Your free box is ready" : "Open a mystery box"}</h1>
        <p className="relative mt-1 text-sm text-white/55">Every box holds one gift, from common to legendary.</p>
        <div className="relative mt-5 flex flex-col gap-2.5">
          {c.features.freeBox && (
            <Button size="lg" disabled={!freeReady || shaking} loading={shaking} onClick={() => openBox("free")}>
              {freeReady ? <><Gift className="h-5 w-5" /> Open free box</> : <><Lock className="h-4 w-4" /> Next free box in {countdown(freeBox.nextAt)}</>}
            </Button>
          )}
          {c.features.paidBox && (
            <Button variant="ghost" disabled={shaking || user.balance < c.paidBoxCost} onClick={() => openBox("paid")}>
              Open a box for <span className="text-amber-300">◆</span> {fmt(c.paidBoxCost)}
            </Button>
          )}
        </div>
      </Glass>

      {/* Daily rewards */}
      {c.features.dailyRewards && daily.rewards.length > 0 && (
        <section aria-labelledby="daily">
          <div className="mb-3 flex items-end justify-between">
            <h2 id="daily" className="font-display text-base font-medium">Daily rewards</h2>
            {daily.streak > 0 && <span className="text-xs text-white/50">{daily.streak}-day streak</span>}
          </div>
          <Glass className="p-3">
            <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
              {daily.rewards.map((r, i) => {
                const done = i < doneUpTo, today = daily.canClaim && i === daily.nextIdx;
                return (
                  <div key={r.day} className={clsx("flex w-[4.4rem] shrink-0 flex-col items-center gap-1.5 rounded-2xl border px-2 py-3", today ? "border-aura-violet bg-aura-violet/20" : "border-white/10 bg-white/[.04]", done && "opacity-60")}>
                    <span className="text-[11px] text-white/50">Day {r.day}</span>
                    <span className="text-2xl leading-none">{done ? <Check className="h-6 w-6 text-emerald-400" /> : r.gift ? r.gift.emoji : "◆"}</span>
                    <span className="text-xs font-bold">{fmt(r.points)}</span>
                  </div>
                );
              })}
            </div>
            <Button className="mt-3 w-full" disabled={!daily.canClaim} loading={claiming} onClick={claimDaily}>
              {daily.canClaim ? `Claim day ${daily.rewards[daily.nextIdx]?.day}` : `Come back in ${countdown(daily.nextAt)}`}
            </Button>
          </Glass>
        </section>
      )}

      {/* Featured gifts */}
      {data.featured.length > 0 && (
        <section aria-labelledby="featured">
          <div className="mb-3 flex items-end justify-between">
            <h2 id="featured" className="font-display text-base font-medium">Featured gifts</h2>
            <Link href="/inventory" className="flex items-center text-xs text-white/50">All gifts <ChevronRight className="h-3.5 w-3.5" /></Link>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2">
            {data.featured.map((g) => <div key={g.id} className="w-[8.2rem] shrink-0"><GiftCard gift={g} onClick={() => setDetail(g)} /></div>)}
          </div>
        </section>
      )}

      {/* Latest winners */}
      <section aria-labelledby="winners">
        <div className="mb-3 flex items-end justify-between">
          <h2 id="winners" className="font-display text-base font-medium">Latest winners</h2>
          <span className="text-xs text-white/40">Demo data</span>
        </div>
        <Glass className="divide-y divide-white/5">
          {data.winners.slice(0, 5).map((w, i) => (
            <div key={i} className="flex items-center gap-3 p-3">
              <GiftArt gift={w.gift} size={42} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{w.name} <span className="font-normal text-white/50">pulled</span> {w.gift.name}</p>
                <p className="text-xs text-white/40">{timeAgo(w.at)}</p>
              </div>
              <RarityBadge rarity={w.gift.rarity} />
            </div>
          ))}
        </Glass>
      </section>

      {/* Events */}
      {data.events.length > 0 && (
        <section aria-labelledby="events">
          <h2 id="events" className="mb-3 font-display text-base font-medium">Special events</h2>
          <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4">
            {data.events.map((e) => (
              <Glass key={e.id} className="w-64 shrink-0 p-4">
                <div className="mb-2 text-3xl">{e.emoji}</div>
                <p className="font-semibold">{e.title}</p>
                <p className="mt-1 text-sm text-white/55">{e.description}</p>
                {e.endsAt && <p className="mt-2 text-xs text-aura-cyan">Ends in {countdown(e.endsAt)}</p>}
              </Glass>
            ))}
          </div>
        </section>
      )}

      {/* Referral banner */}
      {c.features.referrals && (
        <Link href="/referrals" className="block">
          <div className="relative overflow-hidden rounded-3xl p-5 btn-primary">
            <Users className="absolute -right-3 -top-3 h-24 w-24 text-white/15" />
            <p className="font-display text-base font-medium">Invite friends</p>
            <p className="mt-1 max-w-[14rem] text-sm text-white/85">You get {fmt(c.referral.inviterReward)} points and they get {fmt(c.referral.inviteeReward)} when they join.</p>
            <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold">Get your link <ChevronRight className="h-4 w-4" /></span>
          </div>
        </Link>
      )}

      <GiftSheet gift={detail} onClose={() => setDetail(null)} />
      <RevealSheet gift={reveal} onClose={() => setReveal(null)} />
    </div>
  );
}

function RevealSheet({ gift, onClose }: { gift: GiftDto | null; onClose: () => void }) {
  return (
    <Sheet open={!!gift} onClose={onClose} title="New gift">
      {gift && (
        <div className="flex flex-col items-center py-4 text-center">
          <div className="relative">
            <AnimatePresence>
              {[...Array(8)].map((_, i) => (
                <motion.span key={i} initial={{ opacity: 1, x: 0, y: 0, scale: 0.4 }} animate={{ opacity: 0, x: Math.cos((i / 8) * 6.283) * 120, y: Math.sin((i / 8) * 6.283) * 120, scale: 1 }} transition={{ duration: 0.9, ease: "easeOut" }}
                  className="absolute left-1/2 top-1/2 text-lg" aria-hidden><Sparkles className="h-4 w-4 text-amber-300" /></motion.span>
              ))}
            </AnimatePresence>
            <motion.div initial={{ scale: 0.2, rotate: -20, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} transition={{ type: "spring", damping: 10, stiffness: 160 }}>
              <GiftArt gift={gift} size={168} lively />
            </motion.div>
          </div>
          <p className="mt-6 text-sm text-white/50">You got</p>
          <h2 className="font-display text-2xl font-medium">{gift.name}</h2>
          <div className="mt-2"><RarityBadge rarity={gift.rarity} /></div>
          <p className="mt-3 max-w-xs text-sm text-white/60">{gift.description}</p>
          <Link href="/inventory" onClick={onClose} className="mt-6 w-full"><Button className="w-full">See in my gifts</Button></Link>
        </div>
      )}
    </Sheet>
  );
}

function HomeSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><Skeleton className="h-11 w-40" /><Skeleton className="h-9 w-24" /></div>
      <Skeleton className="h-80 w-full rounded-3xl" />
      <Skeleton className="h-40 w-full rounded-3xl" />
      <Skeleton className="h-44 w-full rounded-3xl" />
    </div>
  );
}
