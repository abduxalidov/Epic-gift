import Script from "next/script";
import { AppProvider } from "@/components/AppProvider";
import { BottomNav } from "@/components/BottomNav";

export default function PlayerLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Script src="https://telegram.org/js/telegram-web-app.js" strategy="afterInteractive" />
      <AppProvider>
        <div className="sky min-h-dvh">
          <main className="pb-nav mx-auto max-w-md px-4 pt-[max(1rem,env(safe-area-inset-top))]">{children}</main>
          <BottomNav />
        </div>
      </AppProvider>
    </>
  );
}
