import { readFile } from "fs/promises";
import path from "path";
import { NextRequest, NextResponse } from "next/server";
import { optEnv } from "@/lib/env";

const TYPES: Record<string, string> = { png: "image/png", jpg: "image/jpeg", webp: "image/webp", gif: "image/gif" };

export async function GET(_req: NextRequest, { params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  if (!/^[a-f0-9]{32}\.(png|jpg|webp|gif)$/.test(name)) return new NextResponse("Not found", { status: 404 });
  try {
    const file = await readFile(path.join(optEnv("UPLOAD_DIR", "./uploads"), name));
    return new NextResponse(file, { headers: { "content-type": TYPES[name.split(".")[1]], "cache-control": "public, max-age=31536000, immutable", "x-content-type-options": "nosniff" } });
  } catch {
    return new NextResponse("Not found", { status: 404 });
  }
}
