import { RocketRound } from "@prisma/client";
import { randomInt } from "crypto";
import { db } from "./db";

/** Multiplier is a pure function of server time, so the client can animate it without trusting it. */
export const multiplierAt = (rate: number, ms: number) => Math.exp((rate * Math.max(0, ms)) / 1000);

/** Crash point with a configurable house edge; chosen server-side and hidden until the round ends. */
export function drawCrashPoint(edgePct: number, max: number) {
  const u = randomInt(0, 2 ** 47) / 2 ** 47;
  const edge = edgePct / 100;
  if (u < edge) return 1;
  return Math.min(max, Math.max(1, Math.floor(((1 - edge) / (1 - u)) * 100) / 100));
}

export async function settleIfCrashed(round: RocketRound) {
  if (round.status !== "FLYING") return round;
  const m = multiplierAt(round.growthRate, Date.now() - round.startedAt.getTime());
  if (m < round.crashPoint) return round;
  await db.rocketRound.updateMany({ where: { id: round.id, status: "FLYING" }, data: { status: "CRASHED", endedAt: new Date() } });
  return db.rocketRound.findUniqueOrThrow({ where: { id: round.id } });
}

export function roundDto(r: RocketRound) {
  const open = r.status === "FLYING";
  return {
    id: r.id, status: r.status, bet: r.bet, growthRate: r.growthRate,
    startedAt: r.startedAt.getTime(),
    crashPoint: open ? null : r.crashPoint, // never leak while flying
    cashoutAt: r.cashoutAt, payout: r.payout,
  };
}
