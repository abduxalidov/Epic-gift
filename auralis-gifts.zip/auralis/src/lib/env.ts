/** Read a required secret from the environment. Fails loudly instead of running insecure. */
export function env(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable: ${name}`);
  return v;
}
export const optEnv = (name: string, fallback = "") => process.env[name] ?? fallback;
