import { SignJWT, jwtVerify } from "jose";
import { env } from "./env";

const key = (name: string) => new TextEncoder().encode(env(name));

export const ADMIN_COOKIE = "auralis_admin";

export async function signUserToken(userId: string) {
  return new SignJWT({ k: "user" }).setProtectedHeader({ alg: "HS256" }).setSubject(userId).setIssuedAt().setExpirationTime("12h").sign(key("SESSION_SECRET"));
}
export async function verifyUserToken(token: string): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, key("SESSION_SECRET"), { algorithms: ["HS256"] });
    return payload.k === "user" && payload.sub ? payload.sub : null;
  } catch {
    return null;
  }
}
export async function signAdminToken(adminId: string) {
  return new SignJWT({ k: "admin" }).setProtectedHeader({ alg: "HS256" }).setSubject(adminId).setIssuedAt().setExpirationTime("8h").sign(key("ADMIN_SESSION_SECRET"));
}
export async function verifyAdminToken(token: string): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, key("ADMIN_SESSION_SECRET"), { algorithms: ["HS256"] });
    return payload.k === "admin" && payload.sub ? payload.sub : null;
  } catch {
    return null;
  }
}
