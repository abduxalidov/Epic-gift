import type { Gift } from "@prisma/client";

/** What players may see about a gift (never boxWeight / odds). */
export const giftDto = (g: Gift) => ({
  id: g.id, slug: g.slug, name: g.name, description: g.description, emoji: g.emoji,
  imageUrl: g.imageUrl, rarity: g.rarity, exchangeValue: g.exchangeValue, isFeatured: g.isFeatured,
});
export type GiftDto = ReturnType<typeof giftDto>;
