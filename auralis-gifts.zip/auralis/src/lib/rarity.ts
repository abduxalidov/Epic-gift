export type RarityKey = "COMMON" | "RARE" | "EPIC" | "LEGENDARY";

export const RARITY: Record<RarityKey, { label: string; color: string; glow: string; rank: number; gradient: string }> = {
  COMMON:    { label: "Common",    color: "#94a3b8", glow: "rgba(148,163,184,.35)", rank: 0, gradient: "linear-gradient(135deg,#64748b,#334155)" },
  RARE:      { label: "Rare",      color: "#38bdf8", glow: "rgba(56,189,248,.45)",  rank: 1, gradient: "linear-gradient(135deg,#38bdf8,#4f46e5)" },
  EPIC:      { label: "Epic",      color: "#c084fc", glow: "rgba(192,132,252,.5)",  rank: 2, gradient: "linear-gradient(135deg,#e879f9,#7c3aed)" },
  LEGENDARY: { label: "Legendary", color: "#fbbf24", glow: "rgba(251,191,36,.55)",  rank: 3, gradient: "linear-gradient(135deg,#fde68a,#f59e0b 55%,#ea580c)" },
};
export const RARITY_ORDER: RarityKey[] = ["COMMON", "RARE", "EPIC", "LEGENDARY"];
