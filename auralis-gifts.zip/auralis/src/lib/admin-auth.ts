import { NextRequest } from "next/server";
import { Admin, AdminRole } from "@prisma/client";
import { db } from "./db";
import { ApiError, Ctx, handle } from "./api-server";
import { ADMIN_COOKIE, verifyAdminToken } from "./session";

const RANK: Record<AdminRole, number> = { SUPPORT: 0, MANAGER: 1, SUPER_ADMIN: 2 };

export async function adminFromRequest(req: NextRequest): Promise<Admin | null> {
  const token = req.cookies.get(ADMIN_COOKIE)?.value;
  const id = token ? await verifyAdminToken(token) : null;
  return id ? db.admin.findUnique({ where: { id } }) : null;
}

function assertSameOrigin(req: NextRequest) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const origin = req.headers.get("origin");
  if (origin && new URL(origin).host !== req.headers.get("host")) throw new ApiError(403, "Cross-site request blocked.", "csrf");
}

/** Role-gated admin route. SUPPORT = read-only, MANAGER = content + moderation, SUPER_ADMIN = money & settings. */
export function withAdmin(min: AdminRole, fn: (req: NextRequest, admin: Admin, ctx: Ctx) => Promise<Response>) {
  return handle(async (req, ctx) => {
    assertSameOrigin(req);
    const admin = await adminFromRequest(req);
    if (!admin) throw new ApiError(401, "Sign in to continue.", "unauthorized");
    if (RANK[admin.role] < RANK[min]) throw new ApiError(403, "Your role can't do that.", "forbidden");
    return fn(req, admin, ctx);
  });
}
/** GET is allowed for every admin; writes need `min`. */
export function adminRw(min: AdminRole, fn: (req: NextRequest, admin: Admin, ctx: Ctx) => Promise<Response>) {
  return handle(async (req, ctx) => {
    const need: AdminRole = req.method === "GET" ? "SUPPORT" : min;
    return withAdmin(need, fn)(req, ctx);
  });
}
