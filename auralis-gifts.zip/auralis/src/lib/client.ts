"use client";

export class ApiClientError extends Error {
  constructor(message: string, public status: number, public code?: string) {
    super(message);
  }
}

let token: string | null = typeof window !== "undefined" ? sessionStorage.getItem("auralis_token") : null;
export function setToken(t: string | null) {
  token = t;
  if (typeof window === "undefined") return;
  if (t) sessionStorage.setItem("auralis_token", t);
  else sessionStorage.removeItem("auralis_token");
}

/** Fetch wrapper for the player API. Server decides everything; the client only sends intents. */
export async function api<T>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`/api${path}`, {
      method: opts.method ?? (opts.body ? "POST" : "GET"),
      headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: "no-store",
    });
  } catch {
    throw new ApiClientError("No connection. Check your internet and try again.", 0, "network");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiClientError(data.error ?? "Something went wrong.", res.status, data.code);
  return data as T;
}

export const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong.");

export const fmt = (n: number) => new Intl.NumberFormat("en-US").format(n);
export const fmtDate = (d: string | Date) => new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
export function timeAgo(d: string | Date) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(d).getTime()) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
export function countdown(iso: string | null) {
  if (!iso) return "";
  const s = Math.max(0, Math.floor((new Date(iso).getTime() - Date.now()) / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h > 0 ? `${h}h ${String(m).padStart(2, "0")}m` : `${m}:${String(sec).padStart(2, "0")}`;
}

export const TX_LABEL: Record<string, string> = {
  WELCOME_BONUS: "Welcome bonus", DAILY_REWARD: "Daily reward", FREE_BOX: "Free box", BOX_PURCHASE: "Box opened",
  GIFT_EXCHANGE: "Gift exchanged", PROMO: "Promo code", REFERRAL_INVITER: "Friend joined", REFERRAL_INVITEE: "Referral bonus",
  ROCKET_BET: "Rocket bet", ROCKET_WIN: "Rocket cash-out", ADMIN_ADJUST: "Adjustment by support",
};
