import { z } from "zod";
import { RARITY_ORDER } from "./rarity";

const upload = z.string().regex(/^\/uploads\/[a-f0-9]{32}\.(png|jpg|webp|gif)$/);

export const giftSchema = z.object({
  slug: z.string().min(2).max(40).regex(/^[a-z0-9-]+$/, "Use lowercase letters, numbers and dashes."),
  name: z.string().trim().min(1).max(60),
  description: z.string().trim().min(1).max(300),
  emoji: z.string().min(1).max(8),
  imageUrl: upload.nullable().optional(),
  rarity: z.enum(RARITY_ORDER as [string, ...string[]]),
  exchangeValue: z.number().int().min(0).max(10_000_000),
  boxWeight: z.number().int().min(0).max(1_000_000),
  isActive: z.boolean(),
  isFeatured: z.boolean(),
});

const date = z.string().datetime().nullable().transform((v) => (v ? new Date(v) : null));

export const promoSchema = z.object({
  code: z.string().trim().min(3).max(32).regex(/^[A-Za-z0-9_-]+$/, "Codes use letters, numbers, - and _.").transform((s) => s.toUpperCase()),
  rewardPoints: z.number().int().min(1).max(1_000_000_000),
  maxUses: z.number().int().min(1).max(10_000_000).nullable(),
  expiresAt: date,
  isActive: z.boolean(),
});

export const eventSchema = z.object({
  title: z.string().trim().min(1).max(60),
  description: z.string().trim().min(1).max(200),
  emoji: z.string().min(1).max(8),
  endsAt: date,
  isActive: z.boolean(),
});
