import type { RarityKey } from "./rarity";

export type PublicUser = {
  id: string; telegramId: string; username: string | null; firstName: string; lastName: string | null;
  photoUrl: string | null; balance: number; referralCode: string; dailyStreak: number; createdAt: string;
};
export type GiftDto = {
  id: string; slug: string; name: string; description: string; emoji: string; imageUrl: string | null;
  rarity: RarityKey; exchangeValue: number; isFeatured: boolean;
};
export type Bootstrap = {
  user: PublicUser;
  config: {
    appName: string;
    features: Record<"freeBox" | "paidBox" | "dailyRewards" | "referrals" | "promo" | "exchange" | "rocket", boolean>;
    paidBoxCost: number;
    referral: { inviterReward: number; inviteeReward: number };
  };
  freeBox: { available: boolean; nextAt: string | null };
  daily: {
    canClaim: boolean; nextAt: string | null; streak: number; nextStreak: number; nextIdx: number; claimedIdx: number | null;
    rewards: { day: number; points: number; gift: GiftDto | null }[];
  };
  featured: GiftDto[];
  winners: { name: string; gift: GiftDto; at: string; demo: boolean }[];
  events: { id: string; title: string; description: string; emoji: string; endsAt: string | null }[];
  invited: number;
};
export type InvItem = { id: string; giftId: string; source: string; acquiredAt: string; gift: GiftDto };
