"use client";
import { useCallback, useEffect, useState } from "react";

export class AdminError extends Error {
  constructor(message: string, public status: number) { super(message); }
}

export async function adm<T = any>(path: string, opts: { method?: string; body?: unknown; form?: FormData } = {}): Promise<T> {
  const res = await fetch(`/api/admin${path}`, {
    method: opts.method ?? (opts.body || opts.form ? "POST" : "GET"),
    headers: opts.form ? undefined : { "content-type": "application/json" },
    body: opts.form ?? (opts.body ? JSON.stringify(opts.body) : undefined),
    cache: "no-store",
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.startsWith("/auth/login")) { window.location.href = "/admin/login"; throw new AdminError("Signed out", 401); }
  if (!res.ok) {
    const first = data.issues ? (Object.values(data.issues)[0] as string[] | undefined)?.[0] : null;
    throw new AdminError(first ? `${data.error} ${first}` : data.error ?? "Something went wrong.", res.status);
  }
  return data as T;
}

export function useAdm<T = any>(path: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    if (!path) return;
    setLoading(true);
    try { setData(await adm<T>(path)); setError(null); } catch (e) { setError(e instanceof Error ? e.message : "Failed to load"); } finally { setLoading(false); }
  }, [path]);
  useEffect(() => { load(); }, [load]);
  return { data, error, loading, reload: load };
}

export const money = (n: number) => new Intl.NumberFormat("en-US").format(n);
export const when = (d: string | Date) => new Date(d).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
