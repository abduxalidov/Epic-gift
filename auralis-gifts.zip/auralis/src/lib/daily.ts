import type { User } from "@prisma/client";

const H = 3_600_000;

export function dailyState(user: Pick<User, "lastDailyAt" | "dailyStreak">, rewardCount: number, cooldownH: number, windowH: number) {
  const now = Date.now();
  const last = user.lastDailyAt?.getTime() ?? null;
  const canClaim = last === null || now >= last + cooldownH * H;
  const streakAlive = last !== null && now < last + windowH * H;
  const nextStreak = streakAlive ? user.dailyStreak + 1 : 1;
  const len = Math.max(1, rewardCount);
  return {
    canClaim,
    nextAt: canClaim || last === null ? null : new Date(last + cooldownH * H).toISOString(),
    streak: streakAlive ? user.dailyStreak : 0,
    nextStreak,
    nextIdx: (nextStreak - 1) % len,
    claimedIdx: streakAlive && !canClaim ? (user.dailyStreak - 1) % len : null,
  };
}
