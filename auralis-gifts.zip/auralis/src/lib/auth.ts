import { NextRequest } from "next/server";
import { User } from "@prisma/client";
import { db } from "./db";
import { ApiError, Ctx, handle, rateLimit } from "./api-server";
import { verifyUserToken } from "./session";
import { getSetting } from "./settings";

export async function authUser(req: NextRequest): Promise<User> {
  const h = req.headers.get("authorization");
  const token = h?.startsWith("Bearer ") ? h.slice(7) : null;
  const userId = token ? await verifyUserToken(token) : null;
  if (!userId) throw new ApiError(401, "Your session expired. Reopen the app from Telegram.", "unauthorized");
  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) throw new ApiError(401, "Account not found. Reopen the app from Telegram.", "unauthorized");
  if (user.isBanned) throw new ApiError(403, user.banReason ? `Account suspended: ${user.banReason}` : "This account is suspended.", "banned");
  if (await getSetting<boolean>("app.maintenance")) throw new ApiError(503, "We're doing maintenance. Back soon.", "maintenance");
  return user;
}

/** Authenticated player route. Balance and identity always come from the DB, never from the client. */
export function withUser(fn: (req: NextRequest, user: User, ctx: Ctx) => Promise<Response>, limit = 60) {
  return handle(async (req, ctx) => {
    const user = await authUser(req);
    rateLimit(`u:${user.id}:${req.method}:${req.nextUrl.pathname}`, limit, 60_000);
    return fn(req, user, ctx);
  });
}
