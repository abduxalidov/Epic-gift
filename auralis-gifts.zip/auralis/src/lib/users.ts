import { Prisma, User } from "@prisma/client";
import { db } from "./db";
import { applyDelta, makeCode } from "./economy";
import { getSetting } from "./settings";
import type { TgUser } from "./telegram";

export function publicUser(u: User) {
  return {
    id: u.id,
    telegramId: u.telegramId.toString(),
    username: u.username,
    firstName: u.firstName,
    lastName: u.lastName,
    photoUrl: u.photoUrl,
    balance: u.balance,
    referralCode: u.referralCode,
    dailyStreak: u.dailyStreak,
    createdAt: u.createdAt,
  };
}

export function parseRefCode(startParam?: string | null) {
  const m = startParam?.match(/^(?:ref_)?([A-Z0-9]{6,12})$/i);
  return m ? m[1].toUpperCase() : null;
}

/** Creates the user on first contact (webapp open or /start) or syncs their Telegram profile. */
export async function registerOrSync(tgUser: TgUser, startParam?: string | null) {
  const telegramId = BigInt(tgUser.id);
  const profile = {
    username: tgUser.username ?? null,
    firstName: tgUser.first_name,
    lastName: tgUser.last_name ?? null,
    photoUrl: tgUser.photo_url ?? null,
    languageCode: tgUser.language_code ?? null,
    lastSeenAt: new Date(),
  };

  const existing = await db.user.findUnique({ where: { telegramId } });
  if (existing) {
    // keep an old photo if Telegram did not send a new one
    const user = await db.user.update({ where: { id: existing.id }, data: { ...profile, photoUrl: profile.photoUrl ?? existing.photoUrl } });
    return { user, isNew: false };
  }

  const [welcome, referralsOn, inviterReward, inviteeReward] = await Promise.all([
    getSetting<number>("economy.welcomeBonus"),
    getSetting<boolean>("features.referrals"),
    getSetting<number>("referral.inviterReward"),
    getSetting<number>("referral.inviteeReward"),
  ]);
  const refCode = referralsOn ? parseRefCode(startParam) : null;

  let referralCode = makeCode();
  while (await db.user.findUnique({ where: { referralCode }, select: { id: true } })) referralCode = makeCode();

  try {
    const user = await db.$transaction(async (tx) => {
      const inviter = refCode ? await tx.user.findUnique({ where: { referralCode: refCode } }) : null;
      const created = await tx.user.create({ data: { ...profile, telegramId, referralCode, referredById: inviter?.id ?? null } });
      if (welcome > 0) await applyDelta(tx, created.id, welcome, "WELCOME_BONUS");
      if (inviter && !inviter.isBanned) {
        await tx.referral.create({ data: { inviterId: inviter.id, inviteeId: created.id, rewardPoints: inviterReward } });
        if (inviterReward > 0) await applyDelta(tx, inviter.id, inviterReward, "REFERRAL_INVITER", { inviteeId: created.id });
        if (inviteeReward > 0) await applyDelta(tx, created.id, inviteeReward, "REFERRAL_INVITEE", { inviterId: inviter.id });
      }
      return tx.user.findUniqueOrThrow({ where: { id: created.id } });
    });
    return { user, isNew: true };
  } catch (e) {
    // two parallel first requests: the loser just reads the winner's row
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      const user = await db.user.findUniqueOrThrow({ where: { telegramId } });
      return { user, isNew: false };
    }
    throw e;
  }
}
