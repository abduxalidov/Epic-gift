import { createHmac, timingSafeEqual } from "crypto";
import { env, optEnv } from "./env";

export type TgUser = { id: number; first_name: string; last_name?: string; username?: string; photo_url?: string; language_code?: string };

/**
 * Verifies Telegram WebApp initData per
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 * Returns null when the signature is wrong or the data is stale.
 */
export function verifyInitData(initData: string, botToken: string, maxAgeSec = 60 * 60) {
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash || !/^[a-f0-9]{64}$/i.test(hash)) return null;
  params.delete("hash");
  const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const calc = createHmac("sha256", secret).update(dataCheck).digest();
  const given = Buffer.from(hash, "hex");
  if (given.length !== calc.length || !timingSafeEqual(given, calc)) return null;
  const authDate = Number(params.get("auth_date"));
  if (!authDate || Date.now() / 1000 - authDate > maxAgeSec) return null;
  try {
    const user = JSON.parse(params.get("user") ?? "null") as TgUser | null;
    if (!user || typeof user.id !== "number") return null;
    return { user, startParam: params.get("start_param") ?? undefined };
  } catch {
    return null;
  }
}

export async function tg<T = unknown>(method: string, body: Record<string, unknown>): Promise<T | null> {
  const res = await fetch(`https://api.telegram.org/bot${env("TELEGRAM_BOT_TOKEN")}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = (await res.json().catch(() => null)) as { ok: boolean; result: T } | null;
  if (!data?.ok) {
    console.error("[telegram]", method, data);
    return null;
  }
  return data.result;
}

export const botUsername = () => optEnv("TELEGRAM_BOT_USERNAME");
export const referralLink = (code: string) => `https://t.me/${botUsername()}?startapp=ref_${code}`;
export const appUrl = () => env("APP_URL");
