import { AdminRole } from "@prisma/client";
import { z } from "zod";
import { ApiError, json, readJson } from "./api-server";
import { adminRw } from "./admin-auth";

type Opts = {
  delegate: any; // a Prisma model delegate (db.gift, db.promoCode, ...)
  schema: z.ZodObject<any>;
  role?: AdminRole;
  orderBy?: object;
  include?: object;
  /** return a Response to override the default hard delete (e.g. soft-delete) */
  beforeDelete?: (id: string) => Promise<Response | null>;
};

/** Generic validated list/create/update/delete for simple admin-managed tables. */
export function adminCollection({ delegate, schema, role = "MANAGER", orderBy, include, beforeDelete }: Opts) {
  const collection = adminRw(role, async (req) => {
    if (req.method === "GET") return json({ items: await delegate.findMany({ orderBy, include, take: 500 }) });
    const data = schema.parse(await readJson(req));
    return json({ item: await delegate.create({ data }) }, { status: 201 });
  });
  const item = adminRw(role, async (req, _admin, ctx) => {
    const { id } = await ctx.params;
    if (req.method === "PATCH") {
      const data = schema.partial().parse(await readJson(req));
      return json({ item: await delegate.update({ where: { id }, data }) });
    }
    if (req.method === "DELETE") {
      const override = beforeDelete ? await beforeDelete(id) : null;
      if (override) return override;
      await delegate.delete({ where: { id } });
      return json({ ok: true });
    }
    throw new ApiError(405, "Method not allowed");
  });
  return { collection, item };
}
