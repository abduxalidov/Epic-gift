import { db } from "./db";
import { ApiError } from "./api-server";

export type SettingDef = {
  key: string;
  group: "General" | "Features" | "Boxes" | "Referrals" | "Daily rewards" | "Exchange" | "Rocket demo";
  label: string;
  description?: string;
  type: "boolean" | "int" | "float" | "string";
  default: boolean | number | string;
  min?: number;
  max?: number;
};

/**
 * Registry of every configurable value. `prisma db seed` writes these rows into AppSettings;
 * after that the database is the single source of truth and admins edit them in the dashboard.
 * The `default` here is only used to seed and as a safety net if a row was deleted.
 */
export const SETTING_DEFS: SettingDef[] = [
  { key: "app.name", group: "General", label: "App name", type: "string", default: "Auralis" },
  { key: "app.maintenance", group: "General", label: "Maintenance mode", description: "Blocks all player API calls.", type: "boolean", default: false },
  { key: "economy.welcomeBonus", group: "General", label: "Welcome bonus (points)", type: "int", default: 500, min: 0, max: 1_000_000 },

  { key: "features.freeBox", group: "Features", label: "Free boxes", type: "boolean", default: true },
  { key: "features.paidBox", group: "Features", label: "Boxes bought with demo points", type: "boolean", default: true },
  { key: "features.dailyRewards", group: "Features", label: "Daily rewards", type: "boolean", default: true },
  { key: "features.referrals", group: "Features", label: "Referrals", type: "boolean", default: true },
  { key: "features.promo", group: "Features", label: "Promo codes", type: "boolean", default: true },
  { key: "features.exchange", group: "Features", label: "Gift exchange", type: "boolean", default: true },
  { key: "features.rocket", group: "Features", label: "Rocket demo", type: "boolean", default: true },

  { key: "freeBox.cooldownHours", group: "Boxes", label: "Free box cooldown (hours)", type: "float", default: 12, min: 0, max: 720 },
  { key: "paidBox.cost", group: "Boxes", label: "Box price (points)", type: "int", default: 150, min: 1, max: 1_000_000 },

  { key: "referral.inviterReward", group: "Referrals", label: "Inviter reward (points)", type: "int", default: 250, min: 0, max: 1_000_000 },
  { key: "referral.inviteeReward", group: "Referrals", label: "New player reward (points)", type: "int", default: 100, min: 0, max: 1_000_000 },
  { key: "referral.leaderboardSize", group: "Referrals", label: "Leaderboard size", type: "int", default: 20, min: 3, max: 100 },

  { key: "daily.cooldownHours", group: "Daily rewards", label: "Hours between claims", type: "float", default: 20, min: 1, max: 168 },
  { key: "daily.streakWindowHours", group: "Daily rewards", label: "Hours before streak resets", type: "float", default: 48, min: 1, max: 336 },

  { key: "exchange.feePct", group: "Exchange", label: "Exchange fee (%)", type: "float", default: 0, min: 0, max: 100 },

  { key: "rocket.minBet", group: "Rocket demo", label: "Minimum bet (demo points)", type: "int", default: 10, min: 1, max: 1_000_000 },
  { key: "rocket.maxBet", group: "Rocket demo", label: "Maximum bet (demo points)", type: "int", default: 1000, min: 1, max: 1_000_000 },
  { key: "rocket.houseEdgePct", group: "Rocket demo", label: "House edge (%)", type: "float", default: 4, min: 0, max: 50 },
  { key: "rocket.maxMultiplier", group: "Rocket demo", label: "Maximum multiplier", type: "float", default: 100, min: 1.1, max: 10_000 },
  { key: "rocket.growthRate", group: "Rocket demo", label: "Climb speed", description: "Multiplier = e^(speed × seconds).", type: "float", default: 0.15, min: 0.02, max: 1 },
];

const TTL = 10_000;
let cache: { at: number; map: Map<string, unknown> } | null = null;

export function invalidateSettings() {
  cache = null;
}

export async function allSettings() {
  if (cache && Date.now() - cache.at < TTL) return cache.map;
  const rows = await db.appSettings.findMany();
  const map = new Map<string, unknown>(rows.map((r) => [r.key, r.value]));
  for (const d of SETTING_DEFS) if (!map.has(d.key)) map.set(d.key, d.default); // safety net only
  cache = { at: Date.now(), map };
  return map;
}

export async function getSetting<T extends boolean | number | string>(key: string): Promise<T> {
  const map = await allSettings();
  if (!map.has(key)) throw new Error(`Unknown setting ${key}`);
  return map.get(key) as T;
}

export async function requireFeature(key: string) {
  if (!(await getSetting<boolean>(key))) throw new ApiError(403, "This feature is switched off right now.", "feature_off");
}

export function coerceSetting(def: SettingDef, raw: unknown): boolean | number | string {
  if (def.type === "boolean") {
    if (typeof raw !== "boolean") throw new ApiError(400, `${def.label} must be on or off.`);
    return raw;
  }
  if (def.type === "string") {
    if (typeof raw !== "string" || !raw.trim() || raw.length > 60) throw new ApiError(400, `${def.label} must be 1–60 characters.`);
    return raw.trim();
  }
  const n = Number(raw);
  if (!Number.isFinite(n) || (def.type === "int" && !Number.isInteger(n))) throw new ApiError(400, `${def.label} must be a ${def.type === "int" ? "whole " : ""}number.`);
  if ((def.min !== undefined && n < def.min) || (def.max !== undefined && n > def.max)) throw new ApiError(400, `${def.label} must be between ${def.min} and ${def.max}.`);
  return n;
}
