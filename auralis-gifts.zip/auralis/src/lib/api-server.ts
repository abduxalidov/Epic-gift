import { NextRequest, NextResponse } from "next/server";
import { ZodError } from "zod";
import { Prisma } from "@prisma/client";

export class ApiError extends Error {
  constructor(public status: number, message: string, public code = "error") {
    super(message);
  }
}

/** JSON response that can serialise BigInt (Telegram ids). */
export function json(data: unknown, init?: ResponseInit) {
  return new NextResponse(JSON.stringify(data, (_k, v) => (typeof v === "bigint" ? v.toString() : v)), {
    ...init,
    headers: { "content-type": "application/json", "cache-control": "no-store", ...(init?.headers ?? {}) },
  });
}

export type Ctx = { params: Promise<Record<string, string>> };

/** Wraps a route handler with uniform error handling. */
export function handle(fn: (req: NextRequest, ctx: Ctx) => Promise<Response>) {
  return async (req: NextRequest, ctx: Ctx) => {
    try {
      return await fn(req, ctx);
    } catch (e) {
      if (e instanceof ApiError) return json({ error: e.message, code: e.code }, { status: e.status });
      if (e instanceof ZodError) return json({ error: "Some fields are invalid.", code: "validation", issues: e.flatten().fieldErrors }, { status: 400 });
      if (e instanceof Prisma.PrismaClientKnownRequestError) {
        if (e.code === "P2002") return json({ error: "That value is already in use.", code: "conflict" }, { status: 409 });
        if (e.code === "P2025") return json({ error: "Item not found.", code: "not_found" }, { status: 404 });
      }
      console.error("[api]", req.method, req.nextUrl.pathname, e);
      return json({ error: "Something went wrong. Please try again.", code: "server" }, { status: 500 });
    }
  };
}

export async function readJson(req: NextRequest): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new ApiError(400, "Request body must be valid JSON.", "bad_json");
  }
}

// ---- tiny in-memory rate limiter (swap for Redis/Upstash when running >1 instance) ----
const hits = new Map<string, { n: number; reset: number }>();
export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const e = hits.get(key);
  if (!e || e.reset < now) {
    hits.set(key, { n: 1, reset: now + windowMs });
    if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
    return;
  }
  if (++e.n > limit) throw new ApiError(429, "Too many requests. Wait a moment and try again.", "rate_limited");
}
export const clientIp = (req: NextRequest) => req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
