import { Prisma, TxType } from "@prisma/client";
import { randomInt } from "crypto";
import { ApiError } from "./api-server";

export type Tx = Prisma.TransactionClient;

/**
 * The ONLY place a balance changes. Debits are atomic (`balance >= amount` is part of the UPDATE),
 * and every change writes a Transaction row with the resulting balance.
 */
export async function applyDelta(tx: Tx, userId: string, delta: number, type: TxType, meta?: Prisma.InputJsonValue) {
  if (!Number.isSafeInteger(delta)) throw new Error("Balance delta must be an integer");
  if (delta < 0) {
    const r = await tx.user.updateMany({ where: { id: userId, balance: { gte: -delta } }, data: { balance: { decrement: -delta } } });
    if (r.count === 0) throw new ApiError(400, "Not enough demo points.", "insufficient");
  } else if (delta > 0) {
    await tx.user.update({ where: { id: userId }, data: { balance: { increment: delta } } });
  }
  const u = await tx.user.findUniqueOrThrow({ where: { id: userId }, select: { balance: true } });
  await tx.transaction.create({ data: { userId, type, amount: delta, balanceAfter: u.balance, meta } });
  return u.balance;
}

export function grantGift(tx: Tx, userId: string, giftId: string, source: string) {
  return tx.inventory.create({ data: { userId, giftId, source }, include: { gift: true } });
}

/** Weighted random gift using the gifts' boxWeight (editable in admin). */
export async function drawGift(tx: Tx) {
  const gifts = await tx.gift.findMany({ where: { isActive: true, boxWeight: { gt: 0 } } });
  if (!gifts.length) throw new ApiError(503, "No gifts are available right now.", "empty_pool");
  const total = gifts.reduce((s, g) => s + g.boxWeight, 0);
  let roll = randomInt(0, total);
  for (const g of gifts) {
    if ((roll -= g.boxWeight) < 0) return g;
  }
  return gifts[gifts.length - 1];
}

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function makeCode(len = 8) {
  let s = "";
  for (let i = 0; i < len; i++) s += CODE_ALPHABET[randomInt(0, CODE_ALPHABET.length)];
  return s;
}
