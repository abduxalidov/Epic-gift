/* Registers the webhook, commands and the Mini App menu button.  Usage: npm run bot:webhook */
import { tg, appUrl } from "../src/lib/telegram";
import { env } from "../src/lib/env";

async function main() {
  console.log("setWebhook", await tg("setWebhook", { url: `${appUrl()}/api/telegram/webhook`, secret_token: env("TELEGRAM_WEBHOOK_SECRET"), allowed_updates: ["message"] }));
  console.log("setMyCommands", await tg("setMyCommands", { commands: [{ command: "start", description: "Open the app" }, { command: "help", description: "How it works" }] }));
  console.log("setChatMenuButton", await tg("setChatMenuButton", { menu_button: { type: "web_app", text: "Open", web_app: { url: appUrl() } } }));
}
main();
