import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        night: { 950: "#07060f", 900: "#0c0a1a", 800: "#141029", 700: "#1d1840" },
        aura: { violet: "#8b5cf6", indigo: "#6366f1", blue: "#3b82f6", cyan: "#22d3ee", pink: "#e879f9" },
        rarity: { common: "#94a3b8", rare: "#38bdf8", epic: "#c084fc", legendary: "#fbbf24" },
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-6px)" } },
        shimmer: { "100%": { transform: "translateX(100%)" } },
        pulseGlow: { "0%,100%": { opacity: ".55" }, "50%": { opacity: 1 } },
      },
      animation: {
        float: "float 4s ease-in-out infinite",
        shimmer: "shimmer 1.6s infinite",
        glow: "pulseGlow 2.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
} satisfies Config;
