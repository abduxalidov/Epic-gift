# Auralis: Telegram gift-collection Mini App (demo)

Independent demo inspired by the look and flow of gift-box Mini Apps. Original brand and assets.
**Everything uses virtual demo points: no deposits, no crypto, no withdrawals, no cash value.**

## Stack
Next.js 15 (App Router) · TypeScript · Tailwind 3 · Framer Motion · Lucide · PostgreSQL · Prisma · Telegram Bot API + WebApp SDK

## Run locally
```bash
cp .env.example .env          # fill DATABASE_URL, secrets, ADMIN_USERNAME/ADMIN_PASSWORD
npm install
npx prisma db push            # or: npm run db:migrate
npm run db:seed               # settings, gifts, daily rewards, events, WELCOME promo, first super admin
npm run dev
```
- Player app: `/`  ·  Admin: `/admin` (sign in with the seeded admin)
- Browser testing without Telegram: set `ALLOW_DEV_LOGIN=true` and `NEXT_PUBLIC_ALLOW_DEV_LOGIN=true` (ignored in production builds).

## Connect Telegram
1. Create a bot with @BotFather, put token/username in `.env`, and set `APP_URL` to your public HTTPS URL.
2. `npm run bot:webhook` registers the webhook, `/start` + `/help` commands and the Open menu button.
3. Referral links look like `https://t.me/<bot>?startapp=ref_CODE`; `/start ref_CODE` in chat works too.

## Architecture
```
prisma/schema.prisma        10 required models + RocketRound, Event
src/lib/economy.ts          the only place balances change (atomic debits + Transaction log)
src/lib/settings.ts         registry of every configurable value; DB is the source of truth
src/lib/telegram.ts         initData HMAC verification, Bot API calls
src/lib/auth.ts             player JWT (Bearer) · admin-auth.ts: cookie JWT + roles
src/app/api/**              player API   ·  src/app/api/admin/**  admin API
src/app/(app)/**            player UI    ·  src/app/admin/**      admin UI
```

## Security notes
- initData is verified server-side (HMAC, 1h freshness); the client never sends a balance.
- Debits are `UPDATE … WHERE balance >= amount`; free box, daily claim, exchange, promo use atomic guards against double taps.
- Rocket crash point is drawn server-side and hidden until the round ends; the multiplier is a pure function of server time.
- Admin: bcrypt, httpOnly SameSite=Strict cookie, middleware + per-route role checks (SUPPORT read-only, MANAGER content/bans, SUPER_ADMIN balances/settings), same-origin check on writes, magic-byte validated uploads (no SVG).
- Rate limiting is in-memory: use Redis/Upstash if you run more than one instance. Uploads go to `UPLOAD_DIR`: mount a persistent volume or swap in S3.

## Not verified yet
Written without network access, so `npm install`, `npm run typecheck` and a live Telegram test haven't been run. Expect to fix a few type nits on first run.
