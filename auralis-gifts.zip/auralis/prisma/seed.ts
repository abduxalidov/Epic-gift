/* npm run db:seed  — idempotent: safe to re-run, never overwrites values admins have edited. */
import { PrismaClient, Rarity } from "@prisma/client";
import bcrypt from "bcryptjs";
import { SETTING_DEFS } from "../src/lib/settings";

const db = new PrismaClient();

const GIFTS: [slug: string, name: string, emoji: string, rarity: Rarity, value: number, weight: number, description: string, featured?: boolean][] = [
  ["lucky-clover", "Lucky Clover", "🍀", "COMMON", 20, 300, "A four-leaf charm that always lands on its feet."],
  ["candy-pop", "Candy Pop", "🍬", "COMMON", 15, 300, "Swirled sugar glass. Sweet, shiny, gone in a flash."],
  ["mini-balloon", "Mini Balloon", "🎈", "COMMON", 25, 280, "Floats in any direction you point it."],
  ["cozy-mitten", "Cozy Mitten", "🧤", "COMMON", 20, 260, "Knitted by someone who really likes winter."],
  ["glow-lantern", "Glow Lantern", "🏮", "RARE", 100, 100, "Burns with a soft violet flame that never needs oil.", true],
  ["snow-globe", "Crystal Snow Globe", "🔮", "RARE", 90, 120, "A tiny storm that settles into the shape of your name.", true],
  ["retro-boombox", "Retro Boombox", "📻", "RARE", 110, 110, "Plays songs that haven't been written yet."],
  ["neon-tape", "Neon Cassette", "📼", "RARE", 80, 120, "Side B is always louder."],
  ["star-scope", "Stardust Telescope", "🔭", "EPIC", 320, 40, "Shows constellations before the sky has drawn them.", true],
  ["plush-comet", "Plush Comet", "☄️", "EPIC", 400, 35, "Soft to hold, impossible to catch.", true],
  ["orbit-watch", "Orbit Watch", "⌚", "EPIC", 350, 36, "Keeps time for planets, not people."],
  ["golden-crown", "Golden Crown", "👑", "LEGENDARY", 1500, 6, "Heavier than it looks, brighter than it should be.", true],
  ["phoenix-feather", "Phoenix Feather", "🪶", "LEGENDARY", 2000, 4, "Warm to the touch. Do not leave near curtains.", true],
  ["galaxy-diamond", "Galaxy Diamond", "💎", "LEGENDARY", 3000, 2, "A small galaxy, cut into twelve perfect faces.", true],
];

async function main() {
  for (const d of SETTING_DEFS) {
    await db.appSettings.upsert({
      where: { key: d.key },
      update: { group: d.group, label: d.label, description: d.description }, // never touch `value`
      create: { key: d.key, value: d.default, group: d.group, label: d.label, description: d.description },
    });
  }

  for (const [slug, name, emoji, rarity, exchangeValue, boxWeight, description, featured] of GIFTS) {
    await db.gift.upsert({ where: { slug }, update: {}, create: { slug, name, emoji, rarity, exchangeValue, boxWeight, description, isFeatured: !!featured } });
  }

  if ((await db.dailyReward.count()) === 0) {
    const boombox = await db.gift.findUnique({ where: { slug: "retro-boombox" } });
    const pts = [50, 75, 100, 125, 150, 200, 300];
    await db.dailyReward.createMany({ data: pts.map((points, i) => ({ day: i + 1, points, giftId: i === 6 ? boombox?.id ?? null : null })) });
  }

  if ((await db.event.count()) === 0) {
    await db.event.createMany({
      data: [
        { title: "Comet weekend", description: "Epic gifts show up more often in boxes until Sunday.", emoji: "☄️" },
        { title: "Bring a friend", description: "Both of you get demo points when they join.", emoji: "🤝" },
      ],
    });
  }

  if (!(await db.promoCode.findUnique({ where: { code: "WELCOME" } }))) {
    await db.promoCode.create({ data: { code: "WELCOME", rewardPoints: 200, maxUses: 1000 } });
  }

  const username = (process.env.ADMIN_USERNAME ?? "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD ?? "";
  if (!(await db.admin.count())) {
    if (!username || password.length < 10) throw new Error("Set ADMIN_USERNAME and an ADMIN_PASSWORD of 10+ characters to create the first admin.");
    await db.admin.create({ data: { username, passwordHash: await bcrypt.hash(password, 12), role: "SUPER_ADMIN" } });
    console.log(`Created super admin "${username}"`);
  }
  console.log("Seed complete.");
}

main().finally(() => db.$disconnect());
